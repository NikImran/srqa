<?php 

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "dream_couleur";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName); 
// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}
?>

<!DOCTYPE html>
<html>
<!-- 
###########+ Author: Irfan Rosli +##########
###########+ Author: Affiqah Onn +##########
###+ Dream Couleur Cakes Menu Jellycake +###
########+ Version 4.0 @ 10-09-2018 +######## -->
<head>
	<title>Strawberry Jellycake - Dream Couleur</title>
	<meta charset="utf-8">
		<?php
		session_start();
		$userData = "";
		$userData = $_SESSION['username'];
		$_SESSION['username'] = $userData;
		
		/// uniqueID
		$uniqID = "";
		$uniqID = $_SESSION['uniqID'];
		$_SESSION['uniqID'] = $uniqID;
		?>
	<style type="text/css">
		@import url('https://fonts.googleapis.com/css?family=Dancing+Script|Pangolin|Sue+Ellen+Francisco');
		/****** Navigation *************************************/
		ul{list-style-type: none;
			margin: 0;
			padding: 0;
			overflow: hidden;
			font-family: 'Sue Ellen Francisco', cursive;}

		li{display: inline;}

		li a, #dropbtn{color: #795227;
			text-align: center;
			padding: 14px 16px;
			text-decoration: none;
			display: inline-block;}

		li a:hover, #menudrop:hover #dropbtn{font-weight: bold;
			display: inline-block;
			text-decoration: underline;}

		li#menudrop{display: inline-block;}

		#menudrop-content{font-family: 'Pangolin', cursive;
		font-size: 20px;
			display: none;
			position: absolute;
			background-color: #ffd3d1;
			min-width: 100px;
			box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
			z-index: 1;}

		#menudrop-content a{color: #795227;
			padding: 12px 16px;
			text-decoration: none;
			display: block;
			text-align: left;}

		#menudrop-content a:hover{font-weight: bold;
				text-decoration: underline;}
				
		#menudrop:hover #menudrop-content{display: block;}

		#logo{display: block;
			text-align: center;
			width: 100%;}

		#navigation{font-family: 'Sue Ellen Francisco', cursive;
					font-size: 30px;
					text-align: center;
					width: 100%;}

		#zoom{padding: 10px;
			transition: transform .2s;
			width: 100px;
			height: 100px;
			margin: 0 auto;
			display: inline-block;}

		#zoom:hover {-ms-transform: scale(1.5); /* IE 9 */
					-webkit-transform: scale(1.5); /* Safari 3-8 */
					transform: scale(1.5);}
		/****** Navigation-end *************************************/
		/****** Menu Cakes *****************************************/
		#mainbox{background-color: #DEFDFF; /*sea blue*/
			overflow: hidden;
			margin-left: 2%;
			margin-right: 2%;
			float: none;}

		#intro{background-color: #F6FEFF; /* light blue*/
			position: relative;
			margin: auto;
			margin-left: 2%;
			margin-right: 2%;
			margin-top: 1%;
			margin-bottom: 1%;
			width: 96%; /* fixed*/
			font-family: 'Pangolin', cursive;
			font-size: 20px;
			color: #795227;
			padding-left: 2%;}

		#intro2{color: #795227; /*brown*/
			font-family: 'Sue Ellen Francisco',cursive;
			font-size: 60px;
			text-align: justify;
			margin-left: 40%;
			font-weight: bold;}

		*{box-sizing: border-box;}
		#secbox{background-color: #F6FEFF;
			position: relative;
			margin-left: 2%;
			margin-right: 2%;
			margin-top: 1%;
			margin-bottom: 3%;
			width: 96%; /*fixed*/
			height: 50%;
			float: left;
			display: flex;
		    display: -ms-flexbox; /* IE10 */
    		-ms-flex-wrap: wrap; /* IE10 */
    		flex-wrap: wrap;}

		/* Create two unequal columns that sits next to each other */
		/* Sidebar/left column */
		#sidebox {-ms-flex: 30%; /* IE10 */
    		flex: 30%; /* side :30% Center :70%*/
    		background-color: #F6FEFF;
    		padding: 20px;}

		/* Main column */
		#centerbox {-ms-flex: 70%; /* IE10 */
		    flex: 70%; /* side :30% Center :70%*/
		    background-color: #F6FEFF;
		    padding: 20px;}


		#price{font-family: 'Sue Ellen Francisco', cursive;
			font-size: 70px;
			color: #fa8072;  /*dark pink*/
			margin-top: -16%;
			margin-bottom: 1%;
			text-align: right;
			margin-right: 2%;}

		#allergen{font-family: 'Pangolin', cursive;
			font-size: 20px;
			color: #795227; /*brown*/
			text-align: center;}

		#productinfo{font-family: 'Pangolin', cursive;
			font-size: 26px;
			color: #fa8072;
			text-align: center;
			width: 600px; /*make it smaller content*/
			margin-left: 18%;/*make it center-center*/}


		#btn {background-color: #fa8072;
		  	border: none;
		  	color: #795227;
		  	padding: 1px 32px;
		  	text-align: center;
		  	font-size: 25px;
		  	margin: 4px 2px;
		  	opacity: 0.8;
		  	transition: 0.3s;
		  	font-family: 'Sue Ellen Francisco', cursive;
		  	font-weight: bold;
		  	border: 1px solid #ccc;
		    border-radius: 4px;}

	  	#btn:hover {opacity: 1}


	  	#addbtn{border: none;
		  	color: #795227;
		  	padding: 8px 30px;
		  	text-align: center;
		  	font-size: 20px;
		  	margin: 4px 2px;
		  	font-family: 'Pangolin', cursive;
		  	background-color: #F9E9AD;
		 	opacity: 0.8;
		  	transition: 0.3s;
		    border: none;
  			border-radius: 15px;
  			box-shadow: 0 5px #999;}

		#addbtn:hover {opacity: 1}

		#addbtn:active {background-color: #F9E9AD;
		  	box-shadow: 0 5px #666;
		  	transform: translateY(4px);}

		#inquiry{font-family: 'Pangolin', cursive;
			font-size: 40px;
			margin-left: 20%;
			color: #795227;}

		input[type=text]{width: 30%;
		    padding: 10px 10px;
		    border: 1px solid #ccc;
		    border-radius: 4px;
			margin: 4px 20px;
		    font-size: 25px;
			font-family: 'Sue Ellen Francisco', cursive;
		  	font-weight: bold;
		  	background-color: #fa8072;
		  	opacity: 0.8;
		  	color: #795227;}


		input[type=text]:hover{opacity: 1;}

		#numbox{
		    border: 1px solid #ccc;
		    border-radius: 4px;
			margin: 4px 10px;
			margin-left: 20px;
			margin-right: 20px;
			padding: 1px 10px;
		    font-size: 25px;
			font-family: 'Sue Ellen Francisco', cursive;
		  	font-weight: bold;
		  	background-color: #fa8072;
		  	opacity: 0.8;
		  	color: #795227;}

		 #numbox:hover{opacity: 1;}
			
		#numcandle{
		    border: 1px solid #ccc;
		    border-radius: 4px;
			margin: 4px 10px;
			margin-left: 20px;
			margin-right: 20px;
			padding: 1px 10px;
		    font-size: 25px;
			font-family: 'Sue Ellen Francisco', cursive;
		  	font-weight: bold;
		  	background-color: #fa8072;
		  	opacity: 0.8;
		  	color: #795227;}

		 #numcandle:hover{opacity: 1;}			
			

		/****** Menu Cakes END *************************************/
		/****** Image Slideshow ************************************/
		img {vertical-align: middle;}

		/* Position the image container (needed to position the left and right arrows) */
		.container {position: relative;}

		/* Hide the images by default */
		.mySlides {display: none;}

		/* Add a pointer when hovering over the thumbnail images */
		.cursor {cursor: pointer;}

		/* Next & previous buttons */
		.prev, 
		.next {cursor: pointer;
			  position: absolute;
			  top: 40%;
			  width: auto;
			  padding: 16px;
			  margin-top: -50px;
			  color: white;
			  font-weight: bold;
			  font-size: 20px;
			  border-radius: 0 3px 3px 0;
			  user-select: none;
			  -webkit-user-select: none;}

		/* Position the "next button" to the right */
		.next {right: 0;
		  	border-radius: 3px 0 0 3px;}

		/* On hover, add a black background color with a little bit see-through */
		.prev:hover, 
		.next:hover {background-color: #cecccc;}

		/* Number text (1/3 etc) */
		.numbertext {color: #795227;
				  font-size: 25px;
				  padding: 8px 12px;
				  position: absolute;
				  top: 0;
				  font-family: 'Sue Ellen Francisco', cursive;}

		/* Container for image text */
		.caption-container {text-align: center;
						  background-color: #F6FEFF;
						  padding: 2px 16px;
						  color: white;}

		.row:after {content: "";
				  display: table;
				  clear: both;}

		/* Six columns side by side */
		.column {float: left;
		  		width: 16.66%;}

		/* Add a transparency effect for thumnbail images */
		.demo {opacity: 0.6;}

		.active, 
		.demo:hover {opacity: 1;}
		/****** Image Slideshow END ********************************/		
	</style>
</head>
<body>
	<!-- Main LOGO -->
	<div id="logo">
		<img src="logoDC.png" alt="Dream Couleur" style="width: 50%">
	</div>
	<!-- Navigation Header -->
	<div id="navigation">
		<ul>
			<li><a href="home.php">HOME</a></li>
				<li><a href="aboutus.php">ABOUT US</a></li>
				<li id="menudrop"><a href="menu_main.php" id="dropbtn">MENU</a>
					<div id="menudrop-content">
						<a href="menu_cakes.php">Cake</a>
						<a href="menu_chocolates.php">Chocolate</a>
						<a href="menu_choux.php">Choux</a>
						<a href="menu_pie.php">Pie</a>
						<a href="menu_tart.php">Tart</a>
					</div>
				</li>
				<li><a href="redirect.php">MY ACCOUNT</a></li>
				<li><a href="contact.php">CONTACT US</a></li>
				<div id="zoom"><!-- zoom effect for basket -->
					<li><a href="Scart.php"><img src="cart.png" width="50" height="50"alt="Item Cart"></a></li>
			</div>
		</ul>
	</div>
	<!-- Navigation Header END -->
	<!------------------------------------------------------------------------------------------>
	<!-- Menu Cake -->
	<div id="mainbox">
		<!-- Upper info -->
		<div id="intro">
			HOME / MENU / CAKE / Strawberry Jellycake
			<div id="intro2"> STRAWBERRY JELLYCAKE
				<p id="price">RM 96.00</p>
			</div>
		</div>
		<!-- second box-->
		<div id="secbox">
			<!-- Sidebox for slideshow image-->
			<div id="sidebox">
				<!-- Image slideshow -->
				<div class="container">
				  <div class="mySlides">
				    <div class="numbertext">1 / 2</div>
				    <img src="strawberry_jelly3.jpg" style="width:100%">
				  </div>

				  <!-- <div class="mySlides">
				    <div class="numbertext">2 / 3</div>
				    <img src="strawberry_jelly2.jpg" style="width:100%">
				  </div>
 -->
				  <div class="mySlides">
				    <div class="numbertext">2 / 2</div>
				    <img src="strawberry_jelly1.jpg" style="width:100%">
				  </div>
				  
				  <a class="prev" onclick="plusSlides(-1)">❮</a>
				  <a class="next" onclick="plusSlides(1)">❯</a>

				  <!-- empty line / gap -->
				  <div class="caption-container">
				    <p id="caption"></p>
				  </div>

				  <!-- small image -->
				  <div class="row">
				    <div class="column">
				      <img class="demo cursor" src="strawberry_jelly3.jpg" style="width:100%" onclick="currentSlide(1)" >
				    </div>
				    <!-- <div class="column">
				      <img class="demo cursor" src="strawberry_jelly2.jpg" style="width:100%" onclick="currentSlide(2)">
				    </div> -->
				    <div class="column">
				      <img class="demo cursor" src="strawberry_jelly1.jpg" style="width:100%" onclick="currentSlide(2)" >
				    </div>
				  </div>
				</div>
				<!-- Image Slideshow - END -->
			</div>
			<!--------------------------------------------------------------------------------->
			<!-- centerbox -->
			<div id="centerbox">
				<p id="allergen"><b>Allergen Information: </b> Contains dairy, Contains egg, Is Halal, Is vegan</p>
				<p id="productinfo">The <b>Strawberry Jellycake</b> is one of our super fruity classic sweets. Its base is a fluffy creamy sponge cake, accompanied with soft and rich whipped cream. The fresh berries that are abundantly used throughout this "boxed" sweetness shall freshen up your day!</p>

				<div id="inquiry">
					<form id="number"  method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) ?>" >
					<div id="size">
						Size: <button id="btn" style="margin-left: 90px;"> &plusmn; 1kg</button>
					</div>

					<div id="candle">
							Candle(s): 
							<input type="number" style="margin-left: 3px" id="numcandle" min="0" max="20" placeholder="0" name="candle">
							<!-- <?php
								// $candle="0";
								// if($_SERVER["REQUEST_METHOD"] == "POST"){
								// $candle = test_input($_POST['candle']);
							//}
							?> -->
					</div>

					<div id="message">
						Message: <input id="message" type="text" placeholder="What to write on the cake" name="message"> 
						<!-- <?php
							$message = "";
							// if($_SERVER["REQUEST_METHOD"] == "POST"){
								// $message = test_input($_POST['message']);
						//	}
						?> -->
					</div>

					<div id="quantity">

						<!-- /// -->
						<?php
							$sql = "SELECT Stock FROM cake WHERE CakeID = 6;";
							$result = mysqli_query($conn, $sql);
							while ($row = mysqli_fetch_assoc($result)) {
								$limit = $row['Stock'];
							}
						?>

						Quantity: <input type="number" id="numbox" min="0" placeholder="0" name="boxnum" max="0">

						<!-- /// -->
						<script type="text/javascript">
							var limit = "<?php echo $limit ?>";
							document.getElementById("numbox").max = limit;
						</script>

								<?php
									$message = $menu = $price = ""; 
									$candle =  "0"; 
									$valid = true;
									

										if($_SERVER["REQUEST_METHOD"] == "POST"){
											///
											if($limit < 1){
												echo "Out of Stock!";
												$valid = false;
											}
											else if(empty($_POST["boxnum"])){
												echo "Quantity is Required!";
												$valid = false;
											}
											else if($_POST["boxnum"] < 0){
												echo "Please enter valid input!";
												$valid = false;
											}
											else{
												$candle = ($_POST["candle"]);
												$order = ($_POST["boxnum"]);
												$message = ($_POST["message"]);
										}

									}

									$sql1 = "SELECT CakeName, Price FROM cake WHERE CakeName = 'Strawberry Jellycake'";
									$result = mysqli_query($conn, $sql1);

									while ($row = mysqli_fetch_assoc($result)){
								        $menu = $row['CakeName'];
								        $price = $row['Price'];
								        // $order = $_POST['boxnum'];
								    }
								?>	
							
							<input type="submit" id="addbtn" value="Add to Cart" name="submit">						
								<?php
									if(isset($_POST["submit"]) && $valid == true){
										$sql3 = "INSERT INTO scart(id, name, price, quantity, candle, message, email) VALUES (DEFAULT, '$menu', '$price', '$order', '$candle', '$message', '$userData')";

										if (!mysqli_query($conn, $sql3)){
											echo "Item not added into cart";
											die("Error: " . mysqli_connect_error());
										}
										else{

											echo "Item added to cart!";
											///
											$newStock = $limit - $_POST["boxnum"];
											$sql4 = "UPDATE cake SET Stock = '$newStock' WHERE CakeID = 6;";
											$result4 = mysqli_query($conn, $sql4);

										}

										mysqli_close($conn);
									}

									function test_input($data){
									 $data = trim($data);
									  $data = stripslashes($data);
									  $data = htmlspecialchars($data);
									  return $data;
									}
								?>
						</form>
					</div>
					<p style="font-size: 20px; color: #fa8072; float: right; margin-right: 23%;"> 7 days to delivery </p>
				</div>
			</div>
		</div>
	</div>
	<!------------------------------------------------------------------------------------------>
	<!-- JS -->
	<script type="text/javascript">
		var slideIndex = 1;
		showSlides(slideIndex);

		function plusSlides(n) {
		  showSlides(slideIndex += n);
		}

		function currentSlide(n) {
		  showSlides(slideIndex = n);
		}

		function showSlides(n) {
		  var i;
		  var slides = document.getElementsByClassName("mySlides");
		  var dots = document.getElementsByClassName("demo");
		  var captionText = document.getElementById("caption");
		  if (n > slides.length) {slideIndex = 1}
		  if (n < 1) {slideIndex = slides.length}
		  for (i = 0; i < slides.length; i++) {
		      slides[i].style.display = "none";
		  }
		  for (i = 0; i < dots.length; i++) {
		      dots[i].className = dots[i].className.replace(" active", "");
		  }
		  slides[slideIndex-1].style.display = "block";
		  dots[slideIndex-1].className += " active";
		  captionText.innerHTML = dots[slideIndex-1].alt;
		}
	</script>

</body>
</html>