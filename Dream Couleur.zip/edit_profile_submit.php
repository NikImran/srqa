<?php

session_start();
$userData = $_SESSION['username'];
$_SESSION['username'] = $userData;

/// uniqueID
$uniqID = "";
$uniqID = $_SESSION['uniqID'];
$_SESSION['uniqID'] = $uniqID;

if (isset($_POST['submit'])){

	include_once 'database_accounts.php';

	$username = $email = $password = $phone = $addresss = $state = $postcode = $city = "";

	$username = $_POST['username'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$phone = $_POST['phone'];
	$address = $_POST['address'];
	$state = $_POST['state'];
	$postcode = $_POST['postcode'];
	$city = $_POST['city'];

	if (empty($_POST['username']) || empty($_POST['email']) || empty($_POST['password']) || empty($_POST['phone']) || empty($_POST['address']) || empty($_POST['state']) || empty($_POST['postcode']) || empty($_POST['city'])) {
		header("Location: edit_profile.php");
		exit();
	} else {
		if (!preg_match("/^[a-zA-Z0-9]*$/", $username) || !preg_match("/^[a-zA-Z]*$/", $state) || !preg_match("/^[0-9]*$/", $postcode) || !preg_match("/^[a-zA-Z]*$/", $city)){
			header("Location: edit_profile.php?input=invalid");
			exit();
		} else{
			$sql  = "UPDATE accounts SET name = '$username', email = '$email', password = '$password', phone = '$phone', address = '$address', state = '$state', postcode = '$postcode', city = '$city' ";
			$sql .= "WHERE name = '$userData';";
			$result = mysqli_query($conn, $sql);

			header("Location: profile.php");
			exit();
		}
	}

} else if (isset($_POST['imageButton'])){
	// $imageGet = $_POST['image'];
	$image = $_FILES['image'];

	$imageName = $_FILES['image']['name'];
	$imageTmpName = $_FILES['image']['tmp_name'];
	$imageSize = $_FILES['image']['size'];
	$imageError = $_FILES['image']['error'];
	$imageType = $_FILES['image']['type'];

	$imageExt = explode('.', $imageName);
	$imageActualExt = strtolower(end($imageExt));

	$allowed = array('jpg', 'jpeg', 'png');

	if (in_array($imageActualExt, $allowed)){
		if ($imageError === 0){
			if ($imageSize < 1000000) {
				$imageNameNew = uniqid('', true) . "." . $imageActualExt;
				$imageDestination = 'profile pic/' . $imageNameNew;
				move_uploaded_file($imageTmpName, $imageDestination);
			} else{
				echo "Image is too big!";
			}

		} else{
			echo "Failed to upload!";
		}
	} else{
		echo "Please upload type png, jpg, and jpeg!";
	}

	// $image['name'] = $_POST['$image["name"]'];
	// Get the content of the image
	// $imagetmp = addslashes(file_get_contents($_FILES['image']['temp_profile']));
	// Insert image name and image content in database
	// $sql = "UPDATE accounts SET image = ('$imagetmp', $image') WHERE name = '$userData';";
	// $result = mysqli_query($conn, $newsql);
	header("Location: profile.php?menjadi");
	exit();

} else if (isset($_POST['cancel'])){
	header("Location: profile.php");
	exit();
} else{
	header("Location: edit_profile.php?tak");
	exit();
}