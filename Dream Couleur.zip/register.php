﻿<!DOCTYPE html>

<html>
<!--
########+ Author: Irfan Rosli +##########
##+ Dream Couleur Header Navigation +####
######+ Version 2.0 @ 02-09-2018 +####### -->
<!--
#########+ Author: Nik Imran +###########
#####+ Dream Couleur Register Page +#####
######+ Version 1.0 @ 08-09-2018 +####### -->

    <head>
        <?php
            /// uniqueID
            $uniqID = "";
            $uniqID = $_SESSION['uniqID'];
            $_SESSION['uniqID'] = $uniqID;
        ?>

        <title>Dream Couleur</title>
        <meta charset="utf-8">
        <style type="text/css">

            @import url('https://fonts.googleapis.com/css?family=Dancing+Script|Pangolin|Sue+Ellen+Francisco');
            @import url('https://fonts.googleapis.com/css?family=Pangolin');


            /****** Navigation *************************************/
            ul {
                list-style-type: none;
                margin: 0;
                padding: 0;
                overflow: hidden;
                font-family: 'Sue Ellen Francisco', cursive;
            }

            li {
                display: inline;
            }

                li a, #dropbtn {
                    color: #795227;
                    text-align: center;
                    padding: 14px 16px;
                    text-decoration: none;
                    display: inline-block;
                }

                    li a:hover, #menudrop:hover #dropbtn {
                        font-weight: bold;
                        display: inline-block;
                        text-decoration: underline;
                    }

                li#menudrop {
                    display: inline-block;
                }

            #menudrop-content {
                font-family: 'Pangolin', cursive;
                font-size: 20px;
                display: none;
                position: absolute;
                background-color: #ffd3d1;
                min-width: 100px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
            }

                #menudrop-content a {
                    color: #795227;
                    padding: 12px 16px;
                    text-decoration: none;
                    display: block;
                    text-align: left;
                }

                    #menudrop-content a:hover {
                        font-weight: bold;
                        text-decoration: underline;
                    }

            #menudrop:hover #menudrop-content {
                display: block;
            }

            #logo {
                display: block;
                text-align: center;
                width: 100%;
            }

            #navigation {
                font-family: 'Sue Ellen Francisco', cursive;
                font-size: 30px;
                text-align: center;
                width: 100%;
            }

            #zoom {
                padding: 10px;
                transition: transform .2s;
                width: 100px;
                height: 100px;
                margin: 0 auto;
                display: inline-block;
            }

                #zoom:hover {
                    -ms-transform: scale(1.5); /* IE 9 */
                    -webkit-transform: scale(1.5); /* Safari 3-8 */
                    transform: scale(1.5);
                }
            /****** Navigation-end *************************************/

            /****** Register Content **************************************/
            #register {
                /* Box */
                background-color: #a4f7ff;
                margin: auto;
                width: 64%;
                border: 2px solid #7af3ff;
                padding: 10px;
                padding-top: 40px;
                padding-bottom: 40px;
                text-align: center;
                color: #795227; /* Brown */
                font-family: 'Pangolin', Regular;
                font-size: large;
            }

 
            div.a {
                /* First Column for text */
                grid-column-start: 1;
                grid-column-end: 2;
                text-align: right;
            }

            div.b {
                /* Second Column */
                grid-column-start: 2;
                grid-column-end: 3;
            }

            div.c {
                /* Third Column */
                grid-column-start: 3;
                grid-column-end: 4;
                font-size: 20px;
                margin-left: 10px;
                text-align: left;
            }

            input.a {
                /* Column for Textbox */
                grid-column-start: 2;
                grid-column-end: 3;
                margin-left: 20px;
            }

            input.button {
                /* Button */
                grid-column-start: 2;
                grid-column-end: 3;
                background-color: #fbe57d; /* Yellow */
                border: 2px solid #ffda47;
                color: #795227;
                margin-left: 270px;
                padding: 0px 10px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-family: 'Pangolin', Regular;
                font-size: 16px;
            }

            .grid {
                /* Template for grid */
                display: grid;
                grid-template-columns: 11% 40% 50%;
                grid-gap: 6px;
                grid-template-rows: auto auto auto 22px 22px auto auto auto auto auto;
            }

        </style>
    </head>
    <body>
        <!-- Main LOGO -->
        <div id="logo">
            <img src="logoDC.png" alt="Dream Couleur" style="width: 50%">
        </div>


        <!-- Navigation Header -->
        <div id="navigation">
            <ul>
               <li><a href="home.php">HOME</a></li>
                <li><a href="aboutus.php">ABOUT US</a></li>
                <li id="menudrop"><a href="menu_main.php" id="dropbtn">MENU</a>
                    <div id="menudrop-content">
                        <a href="menu_cakes.php">Cake</a>
                        <a href="menu_chocolates.php">Chocolate</a>
                        <a href="menu_choux.php">Choux</a>
                        <a href="menu_pie.php">Pie</a>
                        <a href="menu_tart.php">Tart</a>
                    </div>
                </li>
                <li><a href="redirect.php">MY ACCOUNT</a></li>
                <li><a href="contact.php">CONTACT US</a></li>
                <div id="zoom"><!-- zoom effect for basket -->
                    <li><a href="Scart.php"><img src="cart.png" width="50" height="50"alt="Item Cart"></a></li>
                </div>
            </ul>
        </div>

        <!-- Register Content -->
             <form action="register_submit.php" method="POST">
                <div id="register" class="grid">
                    <div class="a">Username :</div> <input class="a" type="text" name="username" size="40">
                    <div class="a">Email :</div> <input class="a" type="text" name="email" size="40">
                    <div class="a">Password :</div> <input class="a" type="password" name="password" size="40">
                    <div class="a">Confirm</div> <div class="b">&nbsp;</div>
                    <div class="c"><b>What's the benefit of becoming a member?</b></div>
                    <div class="a">Password :</div> <input class="a" type="password" name="confirm" size="40">
                    <div class="a">Date of Birth :</div> <input class="a" type="date" name="birth" size="40">
                    <div class="c">•Enjoy your 5% discount with every purchase!</div>
                    <div class="a">Phone :</div> <input class="a" type="text" name="phone" size="40">
                    <div class="c">•Celebrate your birthday with us!</div>
                    <div class="a">Address :</div> <input class="a" type="text" name="address" size="40">
                    <div class="c">&nbsp; Buy 1 item and get another for free!</div>
                    <div class="a">State;</div> <input class="a" type="text" name="state" size="40">
                    <div class="a">Postcode;</div> <input class="a" type="text" name="postcode" size="40">
                    <div class="a">City;</div> <input class="a" type="text" name="city" size="40">
                    <input class="button" type="submit" name="submit" value="Register">
                </div>
            </form>
    </body>
</html>