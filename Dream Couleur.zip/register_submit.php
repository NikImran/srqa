<?php

session_start();

/// uniqueID
$uniqID = "";
$uniqID = $_SESSION['uniqID'];
$_SESSION['uniqID'] = $uniqID;

if (isset($_POST['submit'])){

	include_once 'database_accounts.php';

	// Set the variables
	$username = $email = $password = $birth = $phone = $addresss = $state = $postcode = $city = "";
	$points   = 0;

	$available = true;

	$username = $_POST['username'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$birth = $_POST['birth'];
	$phone = $_POST['phone'];
	$address = $_POST['address'];
	$state = $_POST['state'];
	$postcode = $_POST['postcode'];
	$city = $_POST['city'];

	// Check if empty
	if (empty($_POST['username']) || empty($_POST['email']) || empty($_POST['password']) || empty($_POST['birth']) || empty($_POST['phone']) || empty($_POST['address']) || empty($_POST['state']) || empty($_POST['postcode']) || empty($_POST['city'])) {
		header("Location: register.php?form=empty");
		exit();

	} else {

	    // Check if name only contains letters and whitespace
	    if (!preg_match("/^[a-zA-Z0-9]*$/", $username) || !preg_match("/^[0-9]*$/", $phone) || !preg_match("/^[a-zA-Z]*$/", $state) || !preg_match("/^[0-9]*$/", $postcode) || !preg_match("/^[a-zA-Z]*$/", $city)) {
	    	header("Location: register.php?input=invalid");
	    	exit();

	    } else{

	    	// Check if username already used
			$sql = "SELECT name FROM accounts WHERE name = '$username'";
			$result = mysqli_query($conn, $sql);

			// Read data
			while ($row = mysqli_fetch_assoc($result)){
				$compare = $row['name'];
			}

			if ($username == $compare){
				$available = false;

				header("Location: register.php?username=taken");
				exit();
			}

			if ($available == true){

				// Check if password and confirmPassword is tally
				if ($password == $_POST['confirm']){

					// Keep the username as reference
					$userData = $_POST['username'];
					$_SESSION['username'] = $userData;
					header("Location: profile.php?" . $userData);

					// Insert user into database
					$sql  = "INSERT INTO accounts (name, password, email, birth, phone, address, state, postcode, city, points)";
					$sql .= " VALUES ('$username', '$password', '$email', CAST('" . $birth . "' AS DATE), '$phone', '$address', '$state', '$postcode', '$city', '$points');";
					$result = mysqli_query($conn, $sql);

					header("Location: profile.php");
					exit();

				} else {
					header("Location: register.php?password=unmatch");
					exit();
				}

			}
	    }
 	}

} else{
	header("Location: register.php");
	exit();
}