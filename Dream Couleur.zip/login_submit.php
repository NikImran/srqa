<?php

session_start();
/// uniqueID
$uniqID = "";
$uniqID = $_SESSION['uniqID'];
$_SESSION['uniqID'] = $uniqID;

if (isset($_POST['submit'])){

	include_once 'database_accounts.php';

	$username = $password = "";

	//Error handler
	// Check if empty
	if (empty($_POST['username']) || empty($_POST['password'])){
		header("Location: login.php?login=empty");
	} else{

		// Get the input
		$username = $_POST['username'];
		$password = $_POST['password'];

		// Set the sql query
		$sql = "SELECT password FROM accounts WHERE email = '$username'";
		$result = mysqli_query($conn, $sql);

		// Read data
		while ($row = mysqli_fetch_assoc($result)){
			$compare = $row['password'];
		}

		// Check if the entered password is correct
		if ($password == $compare){

			// Keep the username as reference
			$userData = $_POST['username'];
			$_SESSION['username'] = $userData;

			// Pass uniqueID
			$_SESSION['uniqID'] = $uniqID;
			header("Location: profile.php?" . $userData . $uniqID);
			exit();
		} else{
			header("Location: login.php?invalid");
			exit();
		}
	}

} else{
	header("Location: login.php");
	exit();
}