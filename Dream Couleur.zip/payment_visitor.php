<!DOCTYPE html>
<html>
<!-- 
###########+ Author: Irfan Rosli +##########
######+ Dream Couleur Payment Visitor +#####
########+ Version 1.0 @ 16-09-2018 +######## -->
<head>
	<title>Payment - Dream Couleur</title>
	<meta charset="utf-8">
	<style type="text/css">
		@import url('https://fonts.googleapis.com/css?family=Dancing+Script|Pangolin|Sue+Ellen+Francisco');
		/****** Navigation *************************************/
		ul{list-style-type: none;
			margin: 0;
			padding: 0;
			overflow: hidden;
			font-family: 'Sue Ellen Francisco', cursive;}

		li{display: inline;}

		li a, #dropbtn{color: #795227;
			text-align: center;
			padding: 14px 16px;
			text-decoration: none;
			display: inline-block;}

		li a:hover, #menudrop:hover #dropbtn{font-weight: bold;
			display: inline-block;
			text-decoration: underline;}

		li#menudrop{display: inline-block;}

		#menudrop-content{font-family: 'Pangolin', cursive;
		font-size: 20px;
			display: none;
			position: absolute;
			background-color: #ffd3d1; /*pink*/
			min-width: 100px;
			box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
			z-index: 1;}

		#menudrop-content a{color: #795227;
			padding: 12px 16px;
			text-decoration: none;
			display: block;
			text-align: left;}

		#menudrop-content a:hover{font-weight: bold;
				text-decoration: underline;}
				
		#menudrop:hover #menudrop-content{display: block;}

		#logo{display: block;
			text-align: center;
			width: 100%;}

		#navigation{font-family: 'Sue Ellen Francisco', cursive;
					font-size: 30px;
					text-align: center;
					width: 100%;}

		#zoom{padding: 10px;
			transition: transform .2s;
			width: 100px;
			height: 100px;
			margin: 0 auto;
			display: inline-block;}

		#zoom:hover {-ms-transform: scale(1.5); /* IE 9 */
					-webkit-transform: scale(1.5); /* Safari 3-8 */
					transform: scale(1.5);}
		/****** Navigation-end *************************************/
		/****** Boxes          *************************************/
		*{box-sizing: border-box;}
		/*main blue box*/
		#mainbox{background-color: #DEFDFF; /*sea blue*/
			overflow: hidden;
			margin-left: 2%;
			margin-right: 2%;
			float: none;}

		#secbox{background-color: #DEFDFF;
			position: relative;
			margin-left: 2%;
			margin-right: 2%;
			margin-top: 1%;
			margin-bottom: 3%;
			width: 96%; /*fixed*/
			height: 50%;
			float: left;
			display: flex;
		    display: -ms-flexbox; /* IE10 */
    		-ms-flex-wrap: wrap; /* IE10 */
    		flex-wrap: wrap;
    		color: #795227; /*brown*/
    	font-family: 'Pangolin', cursive;}

		/* Create two unequal columns that sits next to each other */
		/* Sidebar/left column */
		#leftbox {-ms-flex: 70%; /* IE10 */
    		flex: 70%; /* side :30% Center :70%*/
    		padding: 20px;
    	font-family: 'Pangolin',cursive;}

		/* right column */
		#rightbox {-ms-flex: 30%; /* IE10 */
		    flex: 30%; /* side :30% Center :70%*/
		    background-color: #FEEAA3; /*caramel*/
		    padding: 20px;}

	    .error {color: #FF0000;}
		/****** Boxes END      *************************************/
		/****** Button         *************************************/
		input[type=submit]{border: none;
		  	color: #795227;
		  	padding: 8px 30px;
		  	text-align: center;
		  	font-size: 20px;
		  	margin: 4px 2px;
		  	font-family: 'Pangolin', cursive;
		  	background-color: #ffd3d1;
		 	opacity: 0.8;
		  	transition: 0.3s;
		    border: none;
  			border-radius: 15px;
  			box-shadow: 0 5px #999;}

		input[type=submit]:hover {opacity: 1}

		input[type=submit]:active {background-color: #ffd3d1;
		  	box-shadow: 0 5px #666;
		  	transform: translateY(4px);}

		/****** Button END    *************************************/

		/****** PHP FORM    *************************************/
		<?php
		// define variables and set to empty values
		$nameErr = $emailErr = $paymentErr = $addsErr = $stateErr = $postcodeErr = $telErr = "";
		$name = $email = $payment =  $adds = $state = $postcode = $city = $tel = "";

		if ($_SERVER["REQUEST_METHOD"] == "POST") {
		  if (empty($_POST["name"])) {
		    $nameErr = "Name is required";
		  } else {
		    $name = test_input($_POST["name"]);
		    // check if name only contains letters and whitespace
		    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
		      $nameErr = "Only letters and white space allowed";
		    }
		  }
		  
		  if (empty($_POST["email"])) {
		    $emailErr = "Email is required";
		  } else {
		    $email = test_input($_POST["email"]);
		    // check if e-mail address is well-formed
		    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		      $emailErr = "Invalid email format";
		    }
		  }

  		  if (empty($_POST["tel"])) {
		    $telErr = "Telephone number is required";
		  } else {
		    $tel= test_input($_POST["tel"]);
		  }

		    
		  if (empty($_POST["adds"])) {
		    $addsErr = "Address is required";
		  } else {
		    $adds= test_input($_POST["adds"]);
		  }

		  if (empty($_POST["state"])) {
		    $stateErr = "State is required";
		  } else {
		    $state= test_input($_POST["state"]);
		  }

		  if (empty($_POST["postcode"])) {
		    $postcodeErr = "Postcode is required";
		  } else {
		    $postcode= test_input($_POST["postcode"]);
		  }		  
		  if (empty($_POST["city"])) {
		  } else {
		    $city= test_input($_POST["city"]);
		  }


		  if (empty($_POST["payment"])) {
		    $paymentErr = "Payment Method is required";
		  } else {
		    $payment = test_input($_POST["payment"]);
		  }
		}

		function test_input($data) {
		  $data = trim($data);
		  $data = stripslashes($data);
		  $data = htmlspecialchars($data);
		  return $data;
		}
		?>
		/****** PHP FORM END   *************************************/
		/****** Modal PopUps    *************************************/

		/* The Modal (background) */
		.modal {
		    display: none; /* Hidden by default */
		    position: fixed; /* Stay in place */
		    z-index: 1; /* Sit on top */
		    left: 0;
		    top: 0;
		    width: 100%; /* Full width */
		    height: 100%; /* Full height */
		    overflow: auto; /* Enable scroll if needed */
		    background-color: rgb(0,0,0); /* Fallback color */
		    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
		    -webkit-animation-name: fadeIn; /* Fade in the background */
		    -webkit-animation-duration: 0.4s;
		    animation-name: fadeIn;
		    animation-duration: 0.4s
		}

		/* Modal Content */
		.modal-content {
		    position: fixed;
		    bottom: 0;
		    background-color: #fefefe;
		    width: 100%;
		    -webkit-animation-name: slideIn;
		    -webkit-animation-duration: 0.4s;
		    animation-name: slideIn;
		    animation-duration: 0.4s
		}

		/* The Close Button */
		.close {
		    color: white;
		    float: right;
		    font-size: 28px;
		    font-weight: bold;
		}

		.close:hover,
		.close:focus {
		    color: #000;
		    text-decoration: none;
		    cursor: pointer;
		}

		.modal-header {
		    padding: 2px 16px;
		    background-color: #ffd3d1;
		    color: #795227;
		}

		.modal-body {padding: 2px 16px;
		/*background-color: #DEFDFF;*/
		background-color: #FEEAA3; /*caramel*/}

		.modal-footer {
		    padding: 2px 16px;
		    background-color: #ffd3d1;
		    color: #795227;
		}

		/* Add Animation */
		@-webkit-keyframes slideIn {
		    from {bottom: -300px; opacity: 0} 
		    to {bottom: 0; opacity: 1}
		}

		@keyframes slideIn {
		    from {bottom: -300px; opacity: 0}
		    to {bottom: 0; opacity: 1}
		}

		@-webkit-keyframes fadeIn {
		    from {opacity: 0} 
		    to {opacity: 1}
		}

		@keyframes fadeIn {
		    from {opacity: 0} 
		    to {opacity: 1}
		}


		hr.line1{border: 3px solid  #FEEAA3;
			border-radius: 5px;}

		hr.line2{border: 3px solid  #f79691;
			border-radius: 5px;}

		/****** Modal PopUps    *************************************/
		/****** Button Hover    *************************************/
		#myBtn {
		  border-radius: 4px;
		  background-color: #FEEAA3;
		  border: none;
		  color: #795227;
		  text-align: center;
		  font-size: 18px;
		  padding: 10px;
		  width: 200px;
		  transition: all 0.5s;
		  cursor: pointer;
		  margin: 5px;
		  font-family: 'Pangolin', cursive;
		}

		#myBtn span {
		  cursor: pointer;
		  display: inline-block;
		  position: relative;
		  transition: 0.5s;
		}

		#myBtn span:after {
		  content: '\00bb';
		  position: absolute;
		  opacity: 0;
		  top: 0;
		  right: -20px;
		  transition: 0.5s;
		}

		#myBtn:hover span {
		  padding-right: 25px;
		}

		#myBtn:hover span:after {
		  opacity: 1;
		  right: 0;
		}

		/****** Button Hover END    *********************************/
	</style>
</head>
<body>
	<!-- Main LOGO -->
	<div id="logo">
		<img src="logoDC.png" alt="Dream Couleur" style="width: 50%">
	</div>
	<!-- Navigation Header -->
	<div id="navigation">
		<ul>
			<li><a href="home.html">HOME</a></li>
			<li><a href="aboutus.html">ABOUT US</a></li>
			<li id="menudrop"><a href="menu_main.html" id="dropbtn">MENU</a>
				<div id="menudrop-content">
					<a href="menu_cakes.html">Cake</a>
					<a href="menu_chocolates.html">Chocolate</a>
					<a href="menu_choux.html">Choux</a>
					<a href="menu_pie.html">Pie</a>
					<a href="menu_tart.html">Tart</a>
				</div>
			</li>
			<li><a href="login.html">MY ACCOUNT</a></li>
			<li><a href="contact.html">CONTACT US</a></li>
			<div id="zoom"><!-- zoom effect for basket -->
				<li><a href="ShoppingCart.html"><img src="cart.png" width="50" height="50"alt="Item Cart"></a></li>
			</div>
		</ul>
	</div>
	<!-- Navigation Header END -->
	<!------------------------------------------------------------------------------------------>
	<!-- Box -->
	<div id="mainbox">
		<div id="secbox">
			<div id="leftbox">
				<h2 style="text-decoration: underline; font-weight: bold;"> BILLLING INFORMATION</h2>
				<p><span class="error">* required field</span></p>
				<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
				  Name: 
				  <input type="text" name="name" value="<?php echo $name;?>">
				  <span class="error">* <?php echo $nameErr;?></span>
				  <br><br>
				  E-mail: 
				  <input type="text" name="email" value="<?php echo $email;?>">
				  <span class="error">* <?php echo $emailErr;?></span>
				  <br><br>
  				  Tel. Number: 
				  <input type="text" name="tel" value="<?php echo $tel;?>">
				  <span class="error">* <?php echo $telErr;?></span>
				  <br><br>
				  Address:
				  <input type="text" name="adds" value="<?php echo $adds;?>">
				  <span class="error">* <?php echo $addsErr;?></span>
				  <br><br>
				  State:
				  <input type="text" name="state" value="<?php echo $state;?>">
				  <span class="error">*   <?php echo $stateErr;?></span>
				 
				  Postcode:
  				  <input type="text" name="postcode" value="<?php echo $postcode;?>">
				  <span class="error">* <?php echo $postcodeErr;?></span>
				  
				  City:
				  <input type="text" name="city" value="<?php echo $city;?>">

				  <br><br>
				  <hr class="line1">
				  <p>Payment Method: </p> 
				  <input type="radio" name="payment" <?php if (isset($payment) && $payment=="bank") echo "checked";?> value="bank">Bank Transfer
				  <input type="radio" name="payment" <?php if (isset($payment) && $payment=="cod") echo "checked";?> value="cod">Cash on Delivery
				  <span class="error">* <?php echo $paymentErr;?></span>
				  <br><br>
				  <input type="submit" name="submit" value="Place Order">
				</form>
			</div>
			<div id="rightbox">
				<h2 style="font-family: 'Pangolin',cursive; text-decoration: underline; font-weight: bold; text-align: center;">ORDER SUMMARY</h2>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<input type="radio" name="delivery" value="deli">Delivery
				<br>
				<input type="radio" name="delivery" value="self">Self-Pickup
				<hr class="line2">
				<h2>Items: RM</h2>
				<h2>Shipping: RM</h2>
				<hr class="line2">
				<h2>Total: RM</h2>



			</div>
			<!-- Trigger/Open The Modal -->
			  <button id="myBtn"><span>Bank Transfer?</span></button>
			  <!-- The Modal -->
			  <div id="myModal" class="modal">
			  		<!-- Modal content -->
				  <div class="modal-content">
				  	<div class="modal-header">
				  		<span class="close">&times;</span>
				  		<h2>Bank Transfer</h2>
					</div>
					<div class="modal-body">
						<p>Please pay the total amount to</p>
						<p>CIMB : 112233445566778899 </p>
						<p>Please copy ORDER ID and paste it in </p>
						<p>the reference during online transfer</p>
					</div>
					<div class="modal-footer">
						<h3>Order ID: #########</h3>
					</div>
					</div>
				</div>

				<!-- 
			  <button id="myBtn"><span>COD</span></button>
			  <div id="myModal" class="modal">
				  <div class="modal-content">
				  	<div class="modal-header">
				  		<span class="close">&times;</span>
				  		<h2>Cash on Delivery</h2>
					</div>
					<div class="modal-body">
						<p>Please prepare the exact amount for payment</p>
					</div>
					<div class="modal-footer">
						<h3>Order ID: 123456789</h3>
					</div>
					</div>
				</div>-->
		</div>
	</div>
	<script>
	// Get the modal
	var modal = document.getElementById('myModal');

	// Get the button that opens the modal
	var btn = document.getElementById("myBtn");

	// Get the <span> element that closes the modal
	var span = document.getElementsByClassName("close")[0];

	// When the user clicks the button, open the modal 
	btn.onclick = function() {
	    modal.style.display = "block";
	}

	// When the user clicks on <span> (x), close the modal
	span.onclick = function() {
	    modal.style.display = "none";
	}

	// When the user clicks anywhere outside of the modal, close it
	window.onclick = function(event) {
	    if (event.target == modal) {
	        modal.style.display = "none";
	    }
	}
	</script>
</body>
</html>