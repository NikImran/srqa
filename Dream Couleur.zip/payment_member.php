<!DOCTYPE html>
<?php 
                        $servername = "localhost";
                        $username = "root";
                        $password = "";
                        $dbname = "dream_couleur";

                        // Create connection
                        $conn = mysqli_connect($servername, $username, $password, $dbname);
                        // Check connection
                        if (!$conn) {
                            die("Connection failed: " . mysqli_connect_error());
                        }
?>
<html>
<!-- 
###########+ Author: Irfan Rosli +##########
######+ Dream Couleur Payment Visitor +#####
########+ Version 1.0 @ 16-09-2018 +######## -->
<head>
	<title>Payment - Dream Couleur</title>
	<meta charset="utf-8">
		<?php
		session_start();
		$userData = "";
		$userData = $_SESSION['username'];
		$_SESSION['username'] = $userData;

	    /// uniqueID
	    $uniqID = "";
	    $uniqID = $_SESSION['uniqID'];
	    $_SESSION['uniqID'] = $uniqID;

	    $valid = true;

	    if ($uniqID == ""){
			header("Location: home.php");
			header("Refresh:0; url=home.php");
			exit();}
		?>
	<style type="text/css">
		@import url('https://fonts.googleapis.com/css?family=Dancing+Script|Pangolin|Sue+Ellen+Francisco');
		/****** Navigation *************************************/
		ul{list-style-type: none;
			margin: 0;
			padding: 0;
			overflow: hidden;
			font-family: 'Sue Ellen Francisco', cursive;}

		li{display: inline;}

		li a, #dropbtn{color: #795227;
			text-align: center;
			padding: 14px 16px;
			text-decoration: none;
			display: inline-block;}

		li a:hover, #menudrop:hover #dropbtn{font-weight: bold;
			display: inline-block;
			text-decoration: underline;}

		li#menudrop{display: inline-block;}

		#menudrop-content{font-family: 'Pangolin', cursive;
		font-size: 20px;
			display: none;
			position: absolute;
			background-color: #ffd3d1; /*pink*/
			min-width: 100px;
			box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
			z-index: 1;}

		#menudrop-content a{color: #795227;
			padding: 12px 16px;
			text-decoration: none;
			display: block;
			text-align: left;}

		#menudrop-content a:hover{font-weight: bold;
				text-decoration: underline;}
				
		#menudrop:hover #menudrop-content{display: block;}

		#logo{display: block;
			text-align: center;
			width: 100%;}

		#navigation{font-family: 'Sue Ellen Francisco', cursive;
					font-size: 30px;
					text-align: center;
					width: 100%;}

		#zoom{padding: 10px;
			transition: transform .2s;
			width: 100px;
			height: 100px;
			margin: 0 auto;
			display: inline-block;}

		#zoom:hover {-ms-transform: scale(1.5); /* IE 9 */
					-webkit-transform: scale(1.5); /* Safari 3-8 */
					transform: scale(1.5);}
		/****** Navigation-end *************************************/
		/****** Boxes          *************************************/
		*{box-sizing: border-box;}
		/*main blue box*/
		#mainbox{background-color: #DEFDFF; /*sea blue*/
			overflow: hidden;
			margin-left: 2%;
			margin-right: 2%;
			float: none;}

		#secbox{background-color: #DEFDFF;
			position: relative;
			margin-left: 2%;
			margin-right: 2%;
			margin-top: 1%;
			margin-bottom: 3%;
			width: 96%; /*fixed*/
			height: 50%;
			float: left;
			display: flex;
		    display: -ms-flexbox; /* IE10 */
    		-ms-flex-wrap: wrap; /* IE10 */
    		flex-wrap: wrap;
    		color: #795227; /*brown*/
    	font-family: 'Pangolin', cursive;}

		/* Create two unequal columns that sits next to each other */
		/* Sidebar/left column */
		#leftbox {-ms-flex: 70%; /* IE10 */
    		flex: 70%; /* side :30% Center :70%*/
    		padding: 20px;
    	font-family: 'Pangolin',cursive;}

		/* right column */
		#rightbox {-ms-flex: 30%; /* IE10 */
		    flex: 30%; /* side :30% Center :70%*/
		    background-color: #FEEAA3; /*caramel*/
		    padding: 20px;}

	    .error {color: #FF0000;}
		/****** Boxes END      *************************************/
		/****** Button         *************************************/
		input[type=submit]{border: none;
		  	color: #795227;
		  	padding: 8px 30px;
		  	text-align: center;
		  	font-size: 20px;
		  	margin: 4px 2px;
		  	font-family: 'Pangolin', cursive;
		  	background-color: #ffd3d1;
		 	opacity: 0.8;
		  	transition: 0.3s;
		    border: none;
  			border-radius: 15px;
  			box-shadow: 0 5px #999;}

		input[type=submit]:hover {opacity: 1}

		input[type=submit]:active {background-color: #ffd3d1;
		  	box-shadow: 0 5px #666;
		  	transform: translateY(4px);}

		/****** Button END    *************************************/


		/****** Modal PopUps    *************************************/

		/* The Modal (background) */
		.modal {
		    display: none; /* Hidden by default */
		    position: fixed; /* Stay in place */
		    z-index: 1; /* Sit on top */
		    left: 0;
		    top: 0;
		    width: 100%; /* Full width */
		    height: 100%; /* Full height */
		    overflow: auto; /* Enable scroll if needed */
		    background-color: rgb(0,0,0); /* Fallback color */
		    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
		    -webkit-animation-name: fadeIn; /* Fade in the background */
		    -webkit-animation-duration: 0.4s;
		    animation-name: fadeIn;
		    animation-duration: 0.4s
		}

		/* Modal Content */
		.modal-content {
		    position: fixed;
		    bottom: 0;
		    background-color: #fefefe;
		    width: 100%;
		    -webkit-animation-name: slideIn;
		    -webkit-animation-duration: 0.4s;
		    animation-name: slideIn;
		    animation-duration: 0.4s
		}

		/* The Close Button */
		.close {
		    color: white;
		    float: right;
		    font-size: 28px;
		    font-weight: bold;
		}

		.close:hover,
		.close:focus {
		    color: #000;
		    text-decoration: none;
		    cursor: pointer;
		}

		.modal-header {
		    padding: 2px 16px;
		    background-color: #ffd3d1;
		    color: #795227;
		}

		.modal-body {padding: 2px 16px;
		/*background-color: #DEFDFF;*/
		background-color: #FEEAA3; /*caramel*/}

		.modal-footer {
		    padding: 2px 16px;
		    background-color: #ffd3d1;
		    color: #795227;
		}

		/* Add Animation */
		@-webkit-keyframes slideIn {
		    from {bottom: -300px; opacity: 0} 
		    to {bottom: 0; opacity: 1}
		}

		@keyframes slideIn {
		    from {bottom: -300px; opacity: 0}
		    to {bottom: 0; opacity: 1}
		}

		@-webkit-keyframes fadeIn {
		    from {opacity: 0} 
		    to {opacity: 1}
		}

		@keyframes fadeIn {
		    from {opacity: 0} 
		    to {opacity: 1}
		}


		hr.line1{border: 3px solid  #FEEAA3;
			border-radius: 5px;}

		hr.line2{border: 3px solid  #f79691;
			border-radius: 5px;}

		/****** Modal PopUps    *************************************/
		/****** Button Hover    *************************************/
		#myBtn {
		  border-radius: 4px;
		  background-color: #FEEAA3;
		  border: none;
		  color: #795227;
		  text-align: center;
		  font-size: 18px;
		  padding: 10px;
		  width: 200px;
		  transition: all 0.5s;
		  cursor: pointer;
		  margin: 5px;
		  font-family: 'Pangolin', cursive;
		}

		#myBtn span {
		  cursor: pointer;
		  display: inline-block;
		  position: relative;
		  transition: 0.5s;
		}

		#myBtn span:after {
		  content: '\00bb';
		  position: absolute;
		  opacity: 0;
		  top: 0;
		  right: -20px;
		  transition: 0.5s;
		}

		#myBtn:hover span {
		  padding-right: 25px;
		}

		#myBtn:hover span:after {
		  opacity: 1;
		  right: 0;
		}

		/****** Button Hover END    *********************************/
	</style>
</head>
<body>
	<!-- Main LOGO -->
	<div id="logo">
		<img src="logoDC.png" alt="Dream Couleur" style="width: 50%">
	</div>
	<!-- Navigation Header -->
	<div id="navigation">
		<ul>
			<li><a href="home.php">HOME</a></li>
			<li><a href="aboutus.php">ABOUT US</a></li>
			<li id="menudrop"><a href="menu_main.php" id="dropbtn">MENU</a>
				<div id="menudrop-content">
					<a href="menu_cakes.php">Cake</a>
					<a href="menu_chocolates.php">Chocolate</a>
					<a href="menu_choux.php">Choux</a>
					<a href="menu_pie.php">Pie</a>
					<a href="menu_tart.php">Tart</a>
				</div>
			</li>
			<li><a href="redirect.php">MY ACCOUNT</a></li>
			<li><a href="contact.php">CONTACT US</a></li>
			<div id="zoom"><!-- zoom effect for basket -->
				<li><a href="Scart.php"><img src="cart.png" width="50" height="50"alt="Item Cart"></a></li>
			</div>
		</ul>
	</div>
	<!-- Navigation Header END -->
	<!------------------------------------------------------------------------------------------>
	<!-- Box -->

	<div id="mainbox">
		<div id="secbox">
			<div id="leftbox">
				<h2 style="text-decoration: underline; font-weight: bold;"> BILLLING INFORMATION</h2>
				<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
				<!--****** PHP FORM    ************************************ -->
				<?php
				
				// define variables and set to empty values
				$paymentErr = $methodErr = "";
				$payment = $method  = "";
				$methodself = 0;
				$methoddeli = 5;
				$methodVal = 0;
				if ($_SERVER["REQUEST_METHOD"] == "POST"){
					if (empty($_POST["payment"])) {
						$paymentErr = "Payment Method is required";
					  } else {
					    $payment = test_input($_POST["payment"]);
					  }
				}

				if ($_SERVER["REQUEST_METHOD"] == "POST"){
					if (empty($_POST["method"])) {
						$methodErr = "Collection Method is required";
				    }elseif($_POST["method"] == 'deli') {
				    	$methodVal = $methoddeli;
				    	$method = test_input($_POST["method"]);
					}elseif($_POST["method"] == 'self') {
				    	$methodVal = $methodself;
				    	$method = test_input($_POST["method"]);
					} else {
				    	$method = test_input($_POST["method"]);

					}
				}

		 		function test_input($data) {
				  $data = trim($data);
				  $data = stripslashes($data);
				  $data = htmlspecialchars($data);
				  return $data;
				}

				//------------------------------------------------------------------------------------------------//
				//include_once 'includes/db.inc.php';

				$sql = "SELECT `name`, `email`, `phone`, `address`, `state`, `postcode`, `city` FROM `accounts` WHERE email = '$userData' ";
				$result = mysqli_query($conn, $sql);

				if (mysqli_num_rows($result) > 0) {
				    // output data of each row
				    while($row = mysqli_fetch_assoc($result)) {
		    	        $username = $row['name'];
				        $phone    = $row['phone'];
				        $address  = $row['address'];
				        $state    = $row['state'];
				        $postcode = $row['postcode'];
				        $city     = $row['city'];
				        $email = $userData;
				      //  $orderID
				       // $method 	$fPrice = item total	$tPrice = total price;

				        echo "Name: " . $row["name"]. "<br><br>". "E-mail: " . $row["email"]. "<br><br>". "Tel. Number: ".  $row["phone"]. "<br><br>". "Address: " . $row["address"]. "<br><br>". "State: ". $row["state"]. "   ". "Postcode: ". $row["postcode"]. "    "."City: ". $row["city"];
				    }
				} else {
				    echo "Please Log in";
				}

				//mysqli_close($conn);
				?>
				<!--/****** PHP FORM END   *************************************/-->


				  <br><br>
				  <hr class="line1">
				  <p>Payment Method: </p> 
				  <input type="radio" name="payment" <?php if (isset($payment) && $payment=="bank") echo "checked";?> value="bank">Bank Transfer
				  <input type="radio" name="payment" <?php if (isset($payment) && $payment=="cod") echo "checked";?> value="cod">Cash on Delivery
				  <span class="error">* <?php echo $paymentErr;?></span>
				  <br><br>
				  <input type="submit" name="submit" value="Place Order" onclick="myFunction()">
				  






				<!-- </form> -->
			</div>
			<div id="rightbox">
				<h2 style="font-family: 'Pangolin',cursive; text-decoration: underline; font-weight: bold; text-align: center;">ORDER SUMMARY</h2>
				<?php
					$sql2 = "SELECT * FROM `scart` WHERE email = '$userData' ";
					$result2 = mysqli_query($conn, $sql2);
					$fPrice=0;
					$tPrice=0;
					$orderID =0;
					$itemName ="";
					$quantity = 0;
					$candle = 0;
					$message = "";
					if (mysqli_num_rows($result2) > 0){
						// output data of each row
						while($row = mysqli_fetch_assoc($result2)) { 
							$tPrice=($row["price"]*$row["quantity"]); 
							$fPrice=($tPrice+$fPrice);
							$itemName = $row["name"];
							$quantity = $row["quantity"];
							$candle = $row["candle"];
							$message = $row["message"];
							echo $row["name"]. " x " . $row["quantity"] ."<br>"."RM ".$tPrice. "<br><br>";
						}
					}  else {
				    echo "No item in cart";
				    $valid = false;
				}
					//mysqli_close($conn);
				?>
				
				<br>
				<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">

				<input type="radio" name="method" <?php if (isset($method) && $method=="deli") echo "checked";?> value="deli">Delivery + RM <?php echo $methoddeli; ?>.00
				<br>
				<input type="radio" name="method" <?php if (isset($method) && $method=="self") echo "checked";?> value="self">Self-Pickup + RM <?php echo $methodself; ?>.00
				<span class="error">* <?php echo $methodErr;?></span>

				<hr class="line2">
				</form>
				<h2>Items: RM <?php echo $fPrice; ?>.00</h2>
				<h2>Shipping: RM <?php echo $methodVal ?>.00</h2>
				<hr class="line2">
				<h2>Total: RM <?php echo ($fPrice + $methodVal) ?>.00</h2>



				<!-- ---------------------------------------------------------------------------------------- -->

				<!-- ---------------------------------------------------------------------------------------- -->
				<?php 
			    // Insert user into database after button is pressed
				// if (isset($_POST['submit'])){
				// 	$sql3 = "INSERT INTO `invoice`(`id`, `name`, `phone`, `address`, `state`, `postcode`, `city`, `email`, `orderID`, `method`, `itemprice`, `totalprice`)";
				// 	$sql3 .= "VALUES (DEFAULT,'$username', '$phone','$address','$state','$postcode','$city','$email','$orderID','$method','$fPrice','$tPrice')";
				// 	$result3 = mysqli_query($conn, $sql3);

				// 	/// Deleting data in temporary database
				// 	$sql4 = "DELETE FROM scart;";
				// 	$result4 = mysqli_query($conn, $sql4);

				// 	/// Emptying uniqueID
				// 	$uniqID = "";
				// 	$_SESSION['uniqID'] = $uniqID;
				// }




				    // Insert user into database after button is pressed
				if (isset($_POST['submit']) && $valid == true){

					

					///
					$sql5 = "SELECT * FROM accounts WHERE email = '$userData'";
					$result5 = mysqli_query($conn, $sql5);
					while ($row = mysqli_fetch_assoc($result5)){
						$userID = $row['id'];
					}

					///
					$sql6 = "SELECT count(1) as num FROM scart;";
					$result6 = mysqli_query($conn, $sql6);
					while ($row = mysqli_fetch_assoc($result6)){
						$count = $row['num'];
					}

					///
					// if ($count > 0){
					// 	$sql7 = "UPDATE invoice SET orderID = '$uniqID', userID = '$userID', method = '$method', itemprice = '$fPrice', totalprice = '$tPrice';";
					// 	$result7 = mysqli_query($conn, $sql7);
					// } else{
						$sql3 = "INSERT INTO invoice (orderID, userID, method, itemprice, totalprice)";
						$sql3 .= "VALUES ('$uniqID', '$userID', '$method', '$fPrice', '$tPrice')";
						$result3 = mysqli_query($conn, $sql3);
					// }
						$sql3 = "INSERT INTO globalscart (id, userID, orderID, name, price, quantity, candle, message, email)";
						$sql3 .= "VALUES (DEFAULT,'$userID','$uniqID',  '$itemName', '$tPrice', '$quantity', '$candle', '$message', '$userData')";
						$result3 = mysqli_query($conn, $sql3);
						

					/// Deleting data in temporary database
					$sql4 = "DELETE FROM scart;";
					$result4 = mysqli_query($conn, $sql4);

					/// Emptying uniqueID
					$uniqID = "";
					$_SESSION['uniqID'] = $uniqID;


				}


			    ?>

				<?php mysqli_close($conn); ?>


			</div>
			<!-- Trigger/Open The Modal -->
			  <button id="myBtn"><span>Bank Transfer?</span></button>
			  <!-- The Modal -->
			  <div id="myModal" class="modal">
			  		<!-- Modal content -->
				  <div class="modal-content">
				  	<div class="modal-header">
				  		<span class="close">&times;</span>
				  		<h2>Bank Transfer</h2>
					</div>
					<div class="modal-body">
						<p>Please pay the total amount to</p>
						<p>CIMB : 112233445566778899 </p>
						<p>Please copy ORDER ID and paste it in </p>
						<p>the reference during online transfer</p>
					</div>
					<div class="modal-footer">
						<h3>Order ID: <?php echo $uniqID; ?></h3>
					</div>
					</div>
				</div>

				<!-- 
			  <button id="myBtn"><span>COD</span></button>
			  <div id="myModal" class="modal">
				  <div class="modal-content">
				  	<div class="modal-header">
				  		<span class="close">&times;</span>
				  		<h2>Cash on Delivery</h2>
					</div>
					<div class="modal-body">
						<p>Please prepare the exact amount for payment</p>
					</div>
					<div class="modal-footer">
						<h3>Order ID: 123456789</h3>
					</div>
					</div>
				</div>-->
		</div>
	</div>
	<script>

	function myFunction() {
		var valid = "<?php echo $valid ?>";
		if (valid == true){
	    	alert("Your order has been sent! Thank You");
	    }
	}

	// Get the modal
	var modal = document.getElementById('myModal');

	// Get the button that opens the modal
	var btn = document.getElementById("myBtn");

	// Get the <span> element that closes the modal
	var span = document.getElementsByClassName("close")[0];

	// When the user clicks the button, open the modal 
	btn.onclick = function() {
	    modal.style.display = "block";
	}

	// When the user clicks on <span> (x), close the modal
	span.onclick = function() {
	    modal.style.display = "none";
	}

	// When the user clicks anywhere outside of the modal, close it
	window.onclick = function(event) {
	    if (event.target == modal) {
	        modal.style.display = "none";
	    }
	}
	</script>
</body>
</html>