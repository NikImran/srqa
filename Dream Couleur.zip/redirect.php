<?php

session_start();
$userData = $_SESSION['username'];
$_SESSION['username'] = $userData;

/// uniqueID
$uniqID = "";
$uniqID = $_SESSION['uniqID'];
$_SESSION['uniqID'] = $uniqID;


if ($userData == "empty"){
	header("Location: login.php");
	exit();
} else if ($userData == "") {
	header("Location: login.php");
	exit();
} else{
	header("Location: profile.php");
	exit();
}