<!DOCTYPE html>
<html>
<!-- 
########+ Author: Irfan Rosli +##########
########+ Author: Affiqah Onn +##########
######+ Dream Couleur About Us +########
######+ Version 3.0 @ 02-09-2018 +####### -->

	<head>
		<title>Contact Us - Dream Couleur</title>
		<meta charset="utf-8">
		<?php
		session_start();
		$userData = "";
		$userData = $_SESSION['username'];
		$_SESSION['username'] = $userData;

		/// uniqueID
		$uniqID = "";
		$uniqID = $_SESSION['uniqID'];
		$_SESSION['uniqID'] = $uniqID;
		?>
		<style type="text/css">
			
			@import url('https://fonts.googleapis.com/css?family=Dancing+Script|Pangolin|Sue+Ellen+Francisco');
			
			/****** Navigation *************************************/
			ul{list-style-type: none;
				margin: 0;
				padding: 0;
				overflow: hidden;
				font-family: 'Sue Ellen Francisco', cursive;}

			li{display: inline;}

			li a, #dropbtn{color: #795227; /*brown*/
				text-align: center;
				padding: 14px 16px;
				text-decoration: none;
				display: inline-block;}

			li a:hover, #menudrop:hover #dropbtn{font-weight: bold;
				display: inline-block;
				text-decoration: underline;}

			li#menudrop{display: inline-block;}

			#menudrop-content{font-family: 'Pangolin', cursive;
			font-size: 20px;
				display: none;
				position: absolute;
				background-color: #ffd3d1; /*pink*/
				min-width: 100px;
				box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
				z-index: 1;}

			#menudrop-content a{color: #795227;
				padding: 12px 16px;
				text-decoration: none;
				display: block;
				text-align: left;}

			#menudrop-content a:hover{font-weight: bold;
					text-decoration: underline;}

			#menudrop:hover #menudrop-content{display: block;}

			#logo{display: block;
				text-align: center;
				width: 100%;}

			#navigation{font-family: 'Sue Ellen Francisco', cursive;
						font-size: 30px;
						text-align: center;
						width: 100%;}

			#zoom{padding: 10px;
				transition: transform .2s;
				width: 100px;
				height: 100px;
				margin: 0 auto;
				display: inline-block;}

			#zoom:hover {-ms-transform: scale(1.5); /* IE 9 */
    					-webkit-transform: scale(1.5); /* Safari 3-8 */
    					transform: scale(1.5);}
    		/****** Navigation-end *************************************/

    		#mainbox{background-color: #fa8072; /*sea blue*/
    			overflow: hidden;
    			margin-left: 20%;
    			margin-right: 20%;
    			float: none;}

    		div#cardbox{background-color: #ffeaa4; /*sea blue*/
    			/*overflow: hidden;*/
    			/*margin-left: 10%;
    			margin-right: 10%;*/
    			margin-top: 2%;
    			margin-bottom: 2%;
    			float: left;}

    		#cardbox2{background-color: #ffeaa4; /*sea blue*/
    			overflow: hidden;
    			margin-left: auto;
    			margin-right: auto;
    			margin-top: 2%;
    			margin-bottom: 2%;
    			float: left;
    			padding-bottom: 70%}

    		#namecard{float: left;
    				color: #fa8072;
    				font-family: 'Dancing Script', cursive;
    				width: 50%;
    				margin-top: 5%;
    				margin-left: 25%;
    				margin-right: 50%;
    				text-align: center;
    				font-size: 25px;}

    		/****** Homepage-Images ************************************/
    		*{ box-sizing: border-box; }
    		#column{float: left;
    			margin-left: 10%;
    			width: 33%;
    			padding: 1px;
    			color: #795227;
    			font-size: 20px;
    			font-family: 'Pangolin', 'cursive';}

    		#card{
    			float: left;
    			margin-left: 27%;
    			width: 33%;
    			padding: 1px;
    			color: #ffeaa4;
    			font-size: 20px;
    			font-family: 'Pangolin', 'cursive';}

    		#imagecol{
    			position: relative;
    			width: 200px;
				height: 200px;
				margin-top: 1%;
				margin-left: 2%;
				margin-right: auto;}

    		#imagerow::after {content: "";
    						clear: both;
    						display: table;}
    		/****** Homepage-Images-END ********************************/
    		/****** Homepage-Images-overlay ****************************/
    		#container {position: relative;
    					/*width: 50%;*/}

    		#image {opacity: 1;
    			display: block;
    			/*width: 100%;
    			height: auto;*/
    			transition: .5s ease;
    			backface-visibility: hidden;}

    		#middle {transition: .5s ease;
    			opacity: 0;
    			position: absolute;
    			top: 50%;
    			left: 50%;
    			transform: translate(-50%, -50%);
    			-ms-transform: translate(-50%, -50%);
    			text-align: center;}
    		#container:hover #image {opacity: 0.3;}

    		#container:hover #middle {opacity: 1;}

    		#text {/*background-color: #4CAF50;*/
    			color: #795227;
    			font-size: 80px;
    			font-family: 'Sue Ellen Francisco', cursive;
    			font-weight: bold;
    			padding: 16px 32px;}

    		#cardcont{color: #795227;
    				font-size: 15px;
    				text-align: center;
    				text-anchor: top;
    				font-family: 'Pangolin', cursive;
    				float: top;
    				padding: 10px 20px;}

    		#subhead {
    				width: 450px;
    				height: 70px;
    				margin-top: -1%;
    				margin-left: 10%;
    				margin-right: auto;}
    		/****** Homepage-Images-overlay END ************************/

		</style>
	</head>

	<body>
		<!-- Main LOGO -->
		<div id="logo">
			<img src="logoDC.png" alt="Dream Couleur" style="width: 50%">
		</div>

		<!-- Navigation Header -->
		<div id="navigation">
			<ul>
				<li><a href="home.php">HOME</a></li>
				<li><a href="aboutus.php">ABOUT US</a></li>
				<li id="menudrop"><a href="menu_main.php" id="dropbtn">MENU</a>
					<div id="menudrop-content">
						<a href="menu_cakes.php">Cake</a>
						<a href="menu_chocolates.php">Chocolate</a>
						<a href="menu_choux.php">Choux</a>
						<a href="menu_pie.php">Pie</a>
						<a href="menu_tart.php">Tart</a>
					</div>
				</li>
				<li><a href="redirect.php">MY ACCOUNT</a></li>
				<li><a href="contact.php">CONTACT US</a></li>
				<div id="zoom"><!-- zoom effect for basket -->
					<li><a href="Scart.php"><img src="cart.png" width="50" height="50"alt="Item Cart"></a></li>
				</div>
			</ul>
		</div>
		<!-- Navigation Header END -->

		<!-- image homepage -->
		<!-- <div id="imagerow">
			<div id="column">
			 image overlay -->
			<!-- 	<div id="container"><img src="premiumcakee.jpg" alt="Premium Cake" style="width: 90%" id="image">
					<div id="middle">
						<div id="text">Premium Cake</div>
					</div>
				</div>
			</div>
			<div id="column"><img src="lifesweeter.png" alt="Signature" style="width: 90%"></div>
			<div id="column">
				 image overlay -->
			<!-- 	<div id="container"><img src="flakytartss.png" alt="Flaky Tarts" style="width: 90%" id="image">
					<div id="middle">
						<div id="text">Flaky Tarts</div>
					</div>
				</div>
			</div>
		</div> --> 
		<!-- image homepage END-->

		<div id="mainbox">
			<div id="column">
				<div id="cardbox">
					<p id="namecard"><b><u>Contact Person</u></b></p>
					<div id="cardcont">
						<p><b>IRFAN ROSLI</b></p>
						<p>OWNER-ARTIST-PATISSIER-INSTRUCTOR</p>
						<p>013-9876543</p>
						<p>----------------------</p>
						<p><b>IMRAN TADJUDDIN</b></p>
						<p>OWNER-ARTIST-PATISSIER-INSTRUCTOR</p>
						<p>018-9842343</p>
						<p>----------------------</p>
						<p><b>IZZAZ IQBAL</b></p>
						<p>ARTIST-PATISSIER</p>
						<p>017-9876475</p>
						<p>----------------------</p>
						<p><b>AFFIQAH ONN</b></p>
						<p>ARTIST-PATISSIERE</p>
						<p>011-5423154</p>
					</div>
				</div>
			</div>
			<div id="column">
				<div id="cardbox2">
					<p id="namecard"><b><u>Locate Us</u></b></p>
					<div id="cardcont">
						<p><b><u>ADDRESS:</u></b></p>
						<p>32, VENICE BLVD. STREET, BUKIT BINTANG, 55100 KUALA LUMPUR, MALAYSIA</p>
						<p>----------------------</p>
						<p><b><u>EMAIL:</u></b></p>
						<p>dreamcouleur@gmail.com</p>
						<p>----------------------</p>
						<p><b><u>OPENING HOURS:</u></b></p>
						<p>MONDAY - SUNDAY: 10AM - 8PM</p>
						<p>CLOSED DURING PUBLIC HOLIDAYS!</p>
						<p>
						</p>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>