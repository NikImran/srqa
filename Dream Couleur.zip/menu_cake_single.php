<!DOCTYPE html>
<html>
<!-- 
########+ Author: Irfan Rosli +##########
########+ Author: Affiqah Onn +##########
######+ Dream Couleur Cakes Menu +#######
######+ Version 3.0 @ 09-09-2018 +####### -->
	<head>
		<title>Single - Dream Couleur</title>
		<meta charset="utf-8">
		<?php
		session_start();
		$userData = "";
		$userData = $_SESSION['username'];
		$_SESSION['username'] = $userData;
		
		/// uniqueID
		$uniqID = "";
		$uniqID = $_SESSION['uniqID'];
		$_SESSION['uniqID'] = $uniqID;
		?>
		<style type="text/css">
			
			@import url('https://fonts.googleapis.com/css?family=Dancing+Script|Pangolin|Sue+Ellen+Francisco');
			/****** Navigation *************************************/
			ul{list-style-type: none;
				margin: 0;
				padding: 0;
				overflow: hidden;
				font-family: 'Sue Ellen Francisco', cursive;}

			li{display: inline;}

			li a, #dropbtn{color: #795227;
				text-align: center;
				padding: 14px 16px;
				text-decoration: none;
				display: inline-block;}

			li a:hover, #menudrop:hover #dropbtn{font-weight: bold;
				display: inline-block;
				text-decoration: underline;}

			li#menudrop{display: inline-block;}

			#menudrop-content{font-family: 'Pangolin', cursive;
			font-size: 20px;
				display: none;
				position: absolute;
				background-color: #ffd3d1;
				min-width: 100px;
				box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
				z-index: 1;}

			#menudrop-content a{color: #795227;
				padding: 12px 16px;
				text-decoration: none;
				display: block;
				text-align: left;}

			#menudrop-content a:hover{font-weight: bold;
					text-decoration: underline;}
					
			#menudrop:hover #menudrop-content{display: block;}

			#logo{display: block;
				text-align: center;
				width: 100%;}

			#navigation{font-family: 'Sue Ellen Francisco', cursive;
						font-size: 30px;
						text-align: center;
						width: 100%;}

			#zoom{padding: 10px;
				transition: transform .2s;
				width: 100px;
				height: 100px;
				margin: 0 auto;
				display: inline-block;}

			#zoom:hover {-ms-transform: scale(1.5); /* IE 9 */
    					-webkit-transform: scale(1.5); /* Safari 3-8 */
    					transform: scale(1.5);}
    		/****** Navigation-end *************************************/
    		/****** Menu Cakes *****************************************/
    		#mainbox{background-color: #DEFDFF; /*sea blue*/
    			overflow: hidden;
    			margin-left: 2%;
    			margin-right: 2%;
    			float: none;}

    		#intro{background-color: #F6FEFF; /* light blie*/
    			position: relative;
    			margin: auto;
    			margin-left: 2%;
    			margin-right: 2%;
    			margin-top: 1%;
    			margin-bottom: 1%;
    			width: 96%; /* fixed*/
    			height: 50%;
    			font-family: 'Dancing Script', cursive;
    			font-size: 80px;
    			color: #fa8072; /*dark pink*/
    			padding-left: 2%;}

			#intro2{font-family: 'Pangolin',cursive;
				font-size: 27px;
				text-align: left;
				margin-left: 20%;
				margin-top: -5%;}

			*{box-sizing: border-box;}
			#types{background-color: #F6FEFF;
				position: relative;
    			margin-left: 2%;
    			margin-right: 2%;
    			margin-top: 1%;
    			margin-bottom: 3%;
    			width: 96%; /*fixed*/
    			height: 50%;
    			float: left;
    			display: flex;}

    		#typesin{flex: 20%;
    			padding: 1%;
    			text-align: center;
    			font-family: 'Pangolin', cursive;
    			font-size: 30px;
    			color: #795227;
    			margin-bottom: 0.1%;}

    		#price{font-family: 'Sue Ellen Francisco', cursive;
    		font-size: 70px;
    		color: #fa8072;
    		margin-top: 1%;
    		margin-bottom: 1%;}

    		#image{width: 50%;
    			margin-left: auto;
    			margin-right: auto;}

    		#image:hover{box-shadow: 0 0 3px 2px rgba(0, 140, 186, 0.5);}

			/****** Menu Cakes END *************************************/
		</style>
	</head>
	<body>
		<!-- Main LOGO -->
		<div id="logo">
			<img src="logoDC.png" alt="Dream Couleur" style="width: 50%">
		</div>
		<!-- Navigation Header -->
		<div id="navigation">
			<ul>
				<li><a href="home.php">HOME</a></li>
				<li><a href="aboutus.php">ABOUT US</a></li>
				<li id="menudrop"><a href="menu_main.php" id="dropbtn">MENU</a>
					<div id="menudrop-content">
						<a href="menu_cakes.php">Cake</a>
						<a href="menu_chocolates.php">Chocolate</a>
						<a href="menu_choux.php">Choux</a>
						<a href="menu_pie.php">Pie</a>
						<a href="menu_tart.php">Tart</a>
					</div>
				</li>
				<li><a href="redirect.php">MY ACCOUNT</a></li>
				<li><a href="contact.php">CONTACT US</a></li>
				<div id="zoom"><!-- zoom effect for basket -->
					<li><a href="Scart.php"><img src="cart.png" width="50" height="50"alt="Item Cart"></a></li>
				</div>
			</ul>
		</div>
		<!-- Navigation Header END -->

		<!-- Menu Cake -->
		<div id="mainbox">
			<div id="intro">
				Cake - 
				<div id="intro2"> We bring to you the highest quality cakes, made from the freshest and finest ingredients available in the market
				</div>
			</div>
			<div id="types">
				<!-- Images -->
				 <div id="typesin">
					<a href="menu_cakes_lemonlush.php">
						<img src="lemonlush_1.jpg" alt="Single" id="image">
					</a>
					<p>Lemon Lush</p>
					<!-- <p id="price">RM 15.00</p> -->
				</div> 
				<div id="typesin">
					<a href="page_construction.php">
						<img src="pumpkinbars_2.jpg" alt="Single" id="image">
					</a>
					<p>Pumpkin Bars</p>
					<!-- <p id="price">RM 15.00</p> -->
				</div>
				<!-- <div id="typesin"> -->
					<!-- <a href="menu_cakes_zebraice.php"> <!- example jer --> 
						<!-- <img src="zebra_ice_1.jpg" alt="Premium" id="image"> -->
					<!-- </a>Zebra Ice Cake -->
					<!-- <p id="price">RM 120.00</p> -->
				<!-- </div> -->
				<!-- <div id="typesin"> -->
					<!-- <a href="menu_cakes_frozenchoco.php"> <!- example jer --> 
						<!-- <img src="chococheese_3.jpg" alt="Premium" id="image"> -->
					<!-- </a>Frozen Chocolate Cake -->
					<!-- <p id="price">RM 120.00</p> -->
				<!-- </div> -->
				<!-- <div id="typesin">
					<a href="menu_cakes_raspshort.php">
						<img src="classic.jpg" alt="Classic" id="image">
					</a>Raspberry Shortcake -->
					<!-- <p id="price">RM 96.00</p> -->
				<!-- </div>
				<div id="typesin">
					<a href="menu_cakes_jellycake.php">
						<img src="strawberry_jelly3.jpg" alt="Classic" id="image"> -->
					<!-- </a>Strawberry Jellycake -->
					<!-- <p id="price">RM 96.00</p> -->
				</div>
			</div>
		</div>
	</body>
</html>