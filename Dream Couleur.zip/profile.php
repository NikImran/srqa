﻿<!DOCTYPE html>
<html>
<!--
########+ Author: Irfan Rosli +##########
##+ Dream Couleur Header Navigation +####
######+ Version 2.0 @ 02-09-2018 +####### -->
<!--
#########+ Author: Nik Imran +###########
#####+ Dream Couleur Profile Page +######
######+ Version 1.0 @ 09-09-2018 +####### -->
<head>

    <?php
        session_start();
        $userData = $_SESSION['username'];
        $_SESSION['username'] = $userData;
        include_once 'database_accounts.php';
        
        /// uniqueID
        $uniqID = "";
        $uniqID = $_SESSION['uniqID'];
        $_SESSION['uniqID'] = $uniqID;
    ?>

    <title>Dream Couleur</title>
    <meta charset="utf-8">
    <style type="text/css">

        @import url('https://fonts.googleapis.com/css?family=Dancing+Script|Pangolin|Sue+Ellen+Francisco');
        @import url('https://fonts.googleapis.com/css?family=Pangolin');


        /****** Navigation *************************************/
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            font-family: 'Sue Ellen Francisco', cursive;
        }

        li {
            display: inline;
        }

            li a, #dropbtn {
                color: #795227;
                text-align: center;
                padding: 14px 16px;
                text-decoration: none;
                display: inline-block;
            }

                li a:hover, #menudrop:hover #dropbtn {
                    font-weight: bold;
                    display: inline-block;
                    text-decoration: underline;
                }

            li#menudrop {
                display: inline-block;
            }

        #menudrop-content {
            font-family: 'Pangolin', cursive;
            font-size: 20px;
            display: none;
            position: absolute;
            background-color: #ffd3d1;
            min-width: 100px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }

            #menudrop-content a {
                color: #795227;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
                text-align: left;
            }

                #menudrop-content a:hover {
                    font-weight: bold;
                    text-decoration: underline;
                }

        #menudrop:hover #menudrop-content {
            display: block;
        }

        #logo {
            display: block;
            text-align: center;
            width: 100%;
        }

        #navigation {
            font-family: 'Sue Ellen Francisco', cursive;
            font-size: 30px;
            text-align: center;
            width: 100%;
        }

        #zoom {
            padding: 10px;
            transition: transform .2s;
            width: 100px;
            height: 100px;
            margin: 0 auto;
            display: inline-block;
        }

            #zoom:hover {
                -ms-transform: scale(1.5); /* IE 9 */
                -webkit-transform: scale(1.5); /* Safari 3-8 */
                transform: scale(1.5);
            }
        /****** Navigation-end *************************************/

        /****** Profile Content **************************************/
        #profile {
            /* Box */
            background-color: none;
            margin: auto;
            margin-left: 300px;
            width: 50%;
            padding-bottom: 30px;
            text-align: center;
            color: #795227; /* Brown */
            font-family: 'Pangolin', Regular;
            font-size: large;
        }

        #profile #profile1 {
            /* Profile Box */
            grid-column-start: 1;
            grid-column-end: 2;
            padding-bottom: 285px;
            width: 100%;
            height: 100%;
            background-image: linear-gradient(#fa8072, #a4f7ff);
            border-top: 2px solid #795227;
            border-left: 2px solid #795227;
        }

        img.a {
            /* First Column for Image*/
            grid-column-start: 1;
            grid-column-end: 2;
            border-radius: 50%;
            margin-top: 10px;
        }

        div.a {
            grid-column-start: 1;
            grid-column-end: 2;
        }

        div.b {
            /* Second Column */
            grid-column-start: 2;
            grid-column-end: 3;
            text-align: left;
            margin-top: 15px;
            margin-left: 50px;
            font-size: 50px;
        }

        div.b1 {
            grid-column-start: 2;
            grid-column-end: 3;
            text-align: left;
            margin-top: 10px;
            margin-left: 50px;
        }

        div.b2 {
            grid-column-start: 2;
            grid-column-end: 3;
            text-align: left;
            margin-top: 10px;
            margin-left: 80px;
        }

        input.a {
            /* Column for Textbox */
            grid-column-start: 3;
            grid-column-end: 4;
            margin-left: 20px;
        }

        input.button {
            /* Button */
            grid-column-start: 1;
            grid-column-end: 2;
            background-color: #fbe57d; /* Yellow */
            border: 2px solid #ffda47;
            color: #795227;
            margin-bottom: 5px;
            padding: 0px 10px;
            text-align: center;
            text-decoration: none;
            font-family: 'Pangolin', Regular;
            font-size: 16px;
        }

        .grid {
            /* Template for grid */
            display: grid;
            grid-template-columns: 24% 75%;
            grid-template-rows: 30px;
            grid-gap: 6px;
        }

    </style>
</head>

<body>
    <!-- Main LOGO -->
    <div id="logo">
        <img src="logoDC.png" alt="Dream Couleur" style="width: 50%">
    </div>

    <?php

    // Set the variables
    $username  = $phone = $addresss = $state = $postcode = $city = "";
    $points = 0;

    // Set the username as reference
    $userData = $_SESSION['username'];
    $_SESSION['username'] = $userData;

    // Get data based on the username
    $sql = "SELECT * FROM accounts WHERE email = '$userData'";
    $result = mysqli_query($conn, $sql);

    while ($row = mysqli_fetch_assoc($result)){
        $username = $row['name'];
        $phone    = $row['phone'];
        $address  = $row['address'];
        $state    = $row['state'];
        $postcode = $row['postcode'];
        $city     = $row['city'];
        $points   = $row['points'];
    }

    ?>

    <!-- Navigation Header -->
    <div id="navigation">
        <ul>
           <li><a href="home.php">HOME</a></li>
                <li><a href="aboutus.php">ABOUT US</a></li>
                <li id="menudrop"><a href="menu_main.php" id="dropbtn">MENU</a>
                    <div id="menudrop-content">
                        <a href="menu_cakes.php">Cake</a>
                        <a href="menu_chocolates.php">Chocolate</a>
                        <a href="menu_choux.php">Choux</a>
                        <a href="menu_pie.php">Pie</a>
                        <a href="menu_tart.php">Tart</a>
                    </div>
                </li>
                <li><a href="redirect.php">MY ACCOUNT</a></li>
                <li><a href="contact.php">CONTACT US</a></li>
                <div id="zoom"><!-- zoom effect for basket -->
                    <li><a href="Scart.php"><img src="cart.png" width="50" height="50"alt="Item Cart"></a></li>
            </div>
        </ul>
    </div>

    <!-- Profile Content -->

    <div id="profile">
        <div class="grid">
            <div id="profile1">
                <img class="a" src="https://www.w3schools.com/howto/img_avatar.png" alt="Avatar" height="130" width="130"><br><br>
                <input class="button" type="button" value="Edit" onclick="window.location.href='edit_profile.php'">
                <div style="font-size: 12px;">                
                <?php
                $sql = "SELECT `name`, `email`, `phone`, `address`, `state`, `postcode`, `city` FROM `accounts` WHERE email = '$userData'";
                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) {
                    // output data of each row
                    while($row = mysqli_fetch_assoc($result)) {
                        echo "Name: " . $row["name"]. "<br><br>". "E-mail: " . $row["email"]. "<br><br>". "Tel. Number: ".  $row["phone"]. "<br><br>". "Address: " . $row["address"]. "<br><br>". "State: ". $row["state"]. "   ". "Postcode: ". $row["postcode"]. "    "."City: ". $row["city"];
                    }
                } else {
                    echo "0 results";
                }
                ?></div>
                <div class="a" id="Username"><b></b></div>
                <div class="a" id="Phone"></div>
                <div class="a" id="Address"></div>
                <div class="a" id="State"></div>
                <div class="a" id="Postcode"></div>
                <div class="a" id="City"></div>
            </div>
            
            <!-- 
            <script type="text/javascript">
                var username = "<?php echo $username ?>";
                var phone    = "<?php echo $phone ?>";
                var address  = "<?php echo $address ?>";
                var state    = "<?php echo $state ?>";
                var postcode = "<?php echo $postcode ?>";
                var city     = "<?php echo $city ?>";
                var points   = "<?php echo $points ?>";

                document.getElementById("Username").innerHTML = username;
                document.getElementById("Phone").innerHTML = phone;
                document.getElementById("Address").innerHTML = address;
                document.getElementById("State").innerHTML = state;
                document.getElementById("Postcode").innerHTML = postcode;
                document.getElementById("City").innerHTML = city;
            </script>
            -->




            <br>
            <div class="b" id="Points"></div>
            <div class="b1"><b>What can you do with your points?</b></div>
            <div class="b2">With these points, you can get RM5 off on your next purchase for 100 points</div>
            <div class="b1"><b>How to collect your points?</b></div>
            <div class="b2">With every RM2 spent, you will receive 1 point</div>

            <script type="text/javascript">
                document.getElementById("Points").innerHTML = "Points : " + points;
            </script>

        </div>
    </div>

</body>
</html>