﻿<!DOCTYPE html>
<html>
<!--
########+ Author: Irfan Rosli +##########
##+ Dream Couleur Header Navigation +####
######+ Version 2.0 @ 02-09-2018 +####### -->
<!--
#########+ Author: Nik Imran +###########
###+ Dream Couleur Edit Profile Page +###
######+ Version 1.0 @ 09-09-2018 +####### -->
    <head>

        <?php
        session_start();
        $userData = $_SESSION['username'];
        $_SESSION['username'] = $userData;

        /// uniqueID
        $uniqID = "";
        $uniqID = $_SESSION['uniqID'];
        $_SESSION['uniqID'] = $uniqID;
        ?>

        <title>Dream Couleur</title>
        <meta charset="utf-8">
        <style type="text/css">

            @import url('https://fonts.googleapis.com/css?family=Dancing+Script|Pangolin|Sue+Ellen+Francisco');
            @import url('https://fonts.googleapis.com/css?family=Pangolin');


            /****** Navigation *************************************/
            ul {
                list-style-type: none;
                margin: 0;
                padding: 0;
                overflow: hidden;
                font-family: 'Sue Ellen Francisco', cursive;
            }

            li {
                display: inline;
            }

                li a, #dropbtn {
                    color: #795227;
                    text-align: center;
                    padding: 14px 16px;
                    text-decoration: none;
                    display: inline-block;
                }

                    li a:hover, #menudrop:hover #dropbtn {
                        font-weight: bold;
                        display: inline-block;
                        text-decoration: underline;
                    }

                li#menudrop {
                    display: inline-block;
                }

            #menudrop-content {
                font-family: 'Pangolin', cursive;
                font-size: 20px;
                display: none;
                position: absolute;
                background-color: #ffd3d1;
                min-width: 100px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
            }

                #menudrop-content a {
                    color: #795227;
                    padding: 12px 16px;
                    text-decoration: none;
                    display: block;
                    text-align: left;
                }

                    #menudrop-content a:hover {
                        font-weight: bold;
                        text-decoration: underline;
                    }

            #menudrop:hover #menudrop-content {
                display: block;
            }

            #logo {
                display: block;
                text-align: center;
                width: 100%;
            }

            #navigation {
                font-family: 'Sue Ellen Francisco', cursive;
                font-size: 30px;
                text-align: center;
                width: 100%;
            }

            #zoom {
                padding: 10px;
                transition: transform .2s;
                width: 100px;
                height: 100px;
                margin: 0 auto;
                display: inline-block;
            }

                #zoom:hover {
                    -ms-transform: scale(1.5); /* IE 9 */
                    -webkit-transform: scale(1.5); /* Safari 3-8 */
                    transform: scale(1.5);
                }
            /****** Navigation-end *************************************/

            /****** Edit Profile Content **************************************/
            #edit_profile {
                /* Box */
                background-color: #a4f7ff;
                margin: auto;
                width: 64%;
                border: 2px solid #7af3ff;
                padding: 10px;
                padding-top: 30px;
                padding-bottom: 30px;
                text-align: center;
                color: #795227; /* Brown */
                font-family: 'Pangolin', Regular;
                font-size: large;
            }

            img.a {
                /* First Column for Image*/
                grid-column-start: 1;
                grid-column-end: 2;
                margin-left: 60px;
                border-radius: 50%;
            }

            div.a {
                grid-column-start: 1;
                grid-column-end: 2;
            }

            div.b {
                /* Second Column */
                grid-column-start: 2;
                grid-column-end: 3;
                text-align: right;
            }

            div.c {
                /* Third Column */
                grid-column-start: 3;
                grid-column-end: 4;
            }

            input.a {
                /* Column for Textbox */
                grid-column-start: 3;
                grid-column-end: 4;
                margin-left: 20px;
            }

            input.image {
                /* Image */
                position: absolute;
                left: 460px;
                top: 490px;
            }

            input.button1 {
                /* Button1 */
                grid-column-start: 3;
                grid-column-end: 4;
                background-color: #fbe57d; /* Yellow */
                border: 2px solid #ffda47;
                color: #795227;
                margin-top: 10px;
                margin-left: 175px;
                padding: 0px 10px;
                text-align: center;
                text-decoration: none;
                font-family: 'Pangolin', Regular;
                font-size: 16px;
            }

            input.button2 {
                /* Button2 */
                grid-column-start: 4;
                grid-column-end: 5;
                background-color: #fbe57d; /* Yellow */
                border: 2px solid #ffda47;
                color: #795227;
                margin-top: 10px;
                margin-right: 5px;
                padding: 0px 10px;
                text-align: center;
                text-decoration: none;
                font-family: 'Pangolin', Regular;
                font-size: 16px;
            }


            .grid {
                /* Template for grid */
                display: grid;
                grid-template-columns: 40% 11% 40%;
                grid-gap: 6px;
                grid-template-rows: 22px 22px auto 22px 22px auto auto auto auto auto;
            }

            .grid1 {
                /* Second Tepmlate */
                display: grid;
                grid-template-columns: 40% 11% 30% 10%;
                grid-gap: 6px;
            }
        </style>
    </head>

    <body>
        <!-- Main LOGO -->
        <div id="logo">
            <img src="logoDC.png" alt="Dream Couleur" style="width: 50%">
        </div>


        <!-- Navigation Header -->
        <div id="navigation">
            <ul>
                <li><a href="home.html">HOME</a></li>
                <li><a href="aboutus.html">ABOUT US</a></li>
                <li id="menudrop"><a href="menu_main.html" id="dropbtn">MENU</a>
                    <div id="menudrop-content">
                        <a href="menu_cakes.html">Cake</a>
                        <a href="menu_chocolates.html">Chocolate</a>
                        <a href="menu_choux.html">Choux</a>
                        <a href="menu_pie.html">Pie</a>
                        <a href="menu_tart.html">Tart</a>
                    </div>
                </li>
                <li><a href="redirect.php">MY ACCOUNT</a></li>
                <li><a href="contact.html">CONTACT US</a></li>
                <div id="zoom"><!-- zoom effect for basket -->
                    <li><a href="Scart.html"><img src="cart.png" width="50" height="50"alt="Item Cart"></a></li>
                </div>
            </ul>
        </div>

        <!-- Edit Profile Content -->
        <div id="edit_profile">
            <form action="edit_profile_submit.php" method="POST" enctype="multipart/form-data">
                <div class="grid">
                    <div class="b">Username :</div> <input class="a" type="text" name="username" size="40">
                    <img class="a" src="https://www.w3schools.com/howto/img_avatar.png" alt="avatar" height="200" width="200">
                    <input id="fileInput" name="image" type="file" style="display: none;">
                    <input class="image" name="imageButton" type="image" src="plus_button.png" alt="Edit" width="50" height="50" draggable="false" onclick="document.getElementById('fileInput').click();">
                    <div class="b">Email :</div> <input class="a" type="text" name="email" size="40">
                    <div class="b">Password :</div> <input class="a" type="password" name="password" size="40">
                    <div class="b">Confirm</div> <div class="c">&nbsp;</div>
                    <div class="b">Password :</div> <input class="a" type="password" name="confirm" size="40">
                    <div class="b">Phone :</div> <input class="a" type="text" name="phone" size="40">
                    <div class="b">Address :</div> <input class="a" type="text" name="address" size="40">
                    <div class="b">State :</div> <input class="a" type="text" name="state" size="40">
                    <div class="b">Postcode :</div> <input class="a" type="text" name="postcode" size="40">
                    <div class="b">City :</div> <input class="a" type="text" name="city" size="40">
                </div>
            <!-- </form> -->
            <div class="grid1">
                <div class="a">&nbsp;</div> <div class="b">&nbsp;</div>
                <!-- <form style="margin: auto; padding: 0;" action="profile.php"> -->
                    <input class="button1" name="cancel" type="submit" value="Cancel">
                <!-- </form> -->
                <!-- <form style="margin: auto; padding: 0;" action="edit_profile_submit.php" method="POST"> -->
                    <input class="button2" name="submit" type="submit" value="Enter">
                <!-- </form> -->
            </div>
        </div>

    </body>
</html>