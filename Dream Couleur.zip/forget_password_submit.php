<?php

session_start();
/// uniqueID
$uniqID = "";
$uniqID = $_SESSION['uniqID'];
$_SESSION['uniqID'] = $uniqID;

if (isset($_POST['submit'])){
	
	include_once "database_accounts.php";

	// Set the variables
	$username = $email = "";

	// Retrieve values
	$username = $_POST['username'];
	$email    = $_POST['email'];

	// Check if empty
	if (empty($username) || empty($email)){
		header("Location: forget_password.php?form=empty");
		exit();
	} else{

		$sql = "SELECT * FROM accounts WHERE name = '$username'";
		$result = mysqli_query($conn, $sql);

		while ($row = mysqli_fetch_assoc($result)) {
			$compare  = $row['email'];
			$password = $row['password'];
		}

		if ($email == $compare){


			ini_set("SMTP", "mail.gmail.com");
			ini_set("smtp_port", "25");
			ini_set('sendmail_from', "1151101319@student.mmu.edu.my");

			// Send email
			$to = "wildpecker999@gmail.com";
			$subject = "Dream Couleur: Password Recovery";
			$header = array("From: 1151101319@student.mmu.edu.my",
							"Reply-To: wildpecker999@gmail.com",
							"X-Mailer: PHP/" . PHP_VERSION
							);
			$header = implode("\r\n", $header);
			mail($to, $subject, $password, $header);
			$error = error_get_last();
			die($error);
			header("Location: login.php");
			exit();
		} else{
			header("Location: forget_password.php?email=invalid?");
			exit();
		}


	}
}