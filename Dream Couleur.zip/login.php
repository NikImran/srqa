﻿<!DOCTYPE html>
<?php 
                        $servername = "localhost";
                        $username = "root";
                        $password = "";
                        $dbname = "dream_couleur";

                        // Create connection
                        $conn = mysqli_connect($servername, $username, $password, $dbname);
                        // Check connection
                        if (!$conn) {
                            die("Connection failed: " . mysqli_connect_error());
                        }
?>
<html>
<!--
########+ Author: Irfan Rosli +##########
##+ Dream Couleur Header Navigation +####
######+ Version 2.0 @ 02-09-2018 +####### -->
<!--
#########+ Author: Nik Imran +###########    
######+ Dream Couleur Login Page +#######
######+ Version 1.0 @ 08-09-2018 +####### -->

    <head>

        <?php
        session_start();
        /// uniqueID
        $uniqID = "";
        $uniqID = $_SESSION['uniqID'];
        $_SESSION['uniqID'] = $uniqID;
        ?>

        <title>Dream Couleur</title>
        <meta charset="utf-8">
        <style type="text/css">

            @import url('https://fonts.googleapis.com/css?family=Dancing+Script|Pangolin|Sue+Ellen+Francisco');
            @import url('https://fonts.googleapis.com/css?family=Pangolin');

            /****** Navigation *************************************/
            ul {
                list-style-type: none;
                margin: 0;
                padding: 0;
                overflow: hidden;
                font-family: 'Sue Ellen Francisco', cursive;
            }

            li {
                display: inline;
            }

                li a, #dropbtn {
                    color: #795227;
                    text-align: center;
                    padding: 14px 16px;
                    text-decoration: none;
                    display: inline-block;
                }

                    li a:hover, #menudrop:hover #dropbtn {
                        font-weight: bold;
                        display: inline-block;
                        text-decoration: underline;
                    }

                li#menudrop {
                    display: inline-block;
                }

            #menudrop-content {
                font-family: 'Pangolin', cursive;
                font-size: 20px;
                display: none;
                position: absolute;
                background-color: #ffd3d1;
                min-width: 100px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
            }

                #menudrop-content a {
                    color: #795227;
                    padding: 12px 16px;
                    text-decoration: none;
                    display: block;
                    text-align: left;
                }

                    #menudrop-content a:hover {
                        font-weight: bold;
                        text-decoration: underline;
                    }

            #menudrop:hover #menudrop-content {
                display: block;
            }

            #logo {
                display: block;
                text-align: center;
                width: 100%;
            }

            #navigation {
                font-family: 'Sue Ellen Francisco', cursive;
                font-size: 30px;
                text-align: center;
                width: 100%;
            }

            #zoom {
                padding: 10px;
                transition: transform .2s;
                width: 100px;
                height: 100px;
                margin: 0 auto;
                display: inline-block;
            }

                #zoom:hover {
                    -ms-transform: scale(1.5); /* IE 9 */
                    -webkit-transform: scale(1.5); /* Safari 3-8 */
                    transform: scale(1.5);
                }
            /****** Navigation-end *************************************/


            /****** Login Content **************************************/
            #login {
                /* Box */
                background-color: #a4f7ff;
                margin: auto;
                width: 45%;
                border: 2px solid #7af3ff;
                padding: 10px;
                padding-top: 90px;
                padding-bottom: 151px;
                text-align: center;
                color: #795227; /* Brown */
                font-family: 'Pangolin', Regular;
                font-size: large;
            }

            field {
                /* Align Text */
                display: inline-block;
                width: 100px;
                margin-right: 30px;
                margin-bottom: 10px;
                text-align: right;
            }

            .button {
                /* Button */
                background-color: #fbe57d; /* Yellow */
                border: 2px solid #ffda47;
                color: #795227;
                padding: 0px 10px;
                margin-right: 80px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-family: 'Pangolin', Regular;
                font-size: 16px;
            }

            .hyperlink {
                /* Hyperlink */
                display: inline-block;
                width: 140px;
                margin-top: 40px;
                margin-right: 30px;
            }

        </style>

    </head>
    <body>
        <!-- Main LOGO -->
        <div id="logo">
            <img src="logoDC.png" alt="Dream Couleur" style="width: 50%">
        </div>


        <!-- Navigation Header -->
        <div id="navigation">
            <ul>
                <li><a href="home.php">HOME</a></li>
                <li><a href="aboutus.php">ABOUT US</a></li>
                <li id="menudrop"><a href="menu_main.php" id="dropbtn">MENU</a>
                    <div id="menudrop-content">
                        <a href="menu_cakes.php">Cake</a>
                        <a href="menu_chocolates.php">Chocolate</a>
                        <a href="menu_choux.php">Choux</a>
                        <a href="menu_pie.php">Pie</a>
                        <a href="menu_tart.php">Tart</a>
                    </div>
                </li>
                <li><a href="redirect.php">MY ACCOUNT</a></li>
                <li><a href="contact.php">CONTACT US</a></li>
                <div id="zoom"><!-- zoom effect for basket -->
                    <li><a href="Scart.php"><img src="cart.png" width="50" height="50"alt="Item Cart"></a></li>
                </div>
            </ul>
        </div>

        <!-- Login Content -->
        <div id="login">
            <form action="login_submit.php" method="POST">
                <field for="username">Username :</field> <input type="text" name="username" size="40"><br>
                <field for="password">Password :</field> <input type="password" name="password" size="40"><br>
                <input type="submit" name="submit" value="Enter" class="button" style="float:right"><br>
                <a href="forget_password.php" class="hyperlink" style="float:right">Forgot Password?</a> <a href="register.php" class="hyperlink" style="float:right">Not Yet Register?</a>
            </form>
        </div>

        <?php
            $userData = "";
            $userData = $_SESSION['username'];
            $_SESSION['username'] = $userData;
        ?>


    </body>
</html>